import AgGridComponent from '../../components/AgGridComponent/AgGridComponent.vue'
import { mapActions, mapGetters } from 'vuex'

export default {
  name: 'SignatureDocs',
  data() {
    return {
      displayedDocuments: {}
    }
  },
  components: {
    AgGridComponent
  },
  methods: {
    getDocuments(docStatus) {
      if(docStatus) {
        this.$store.dispatch('signatureDocs/fetchPending', this.documents)
        this.displayedDocuments = this.$store.state.signatureDocs.pendingDocuments.items
      } else {
        this.$store.dispatch('signatureDocs/fetchSigned', this.documents)
        this.displayedDocuments = this.$store.state.signatureDocs.signedDocuments.items
      }
    }
  },
  created () {
    this.$store.dispatch('fetchData')
  },
  computed: {
    ...mapActions({ fetchData: "signatureDocs/fetchData" }),
    ...mapGetters({
      documents: 'signatureDocs/documents'
    })
  }
}