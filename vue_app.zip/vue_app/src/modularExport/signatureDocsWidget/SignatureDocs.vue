<template>
  <div id="app">
    <TableComponent />
  </div>
</template>

<script>
import TableComponent from '../../components/TableComponent/TableComponent.vue'

export default {
  name: 'App',
  components: {
    TableComponent
  }
}
</script>