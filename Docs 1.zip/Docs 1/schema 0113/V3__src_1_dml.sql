INSERT INTO dbo.src
(src_id, src_cd, src_nm, crte_dttm, crte_by_id, actv_ind)
VALUES
('1', 'CDID', 'Caterpillar Dealer Indicative Data', current_timestamp, 'devadmin', TRUE),
('2', 'UCID', 'Universal Customer ID', current_timestamp, 'devadmin', TRUE),
('3', 'JV', 'Reference Data', current_timestamp, 'devadmin', TRUE),
('4', 'GD', 'Global Directory', current_timestamp, 'devadmin', TRUE),
('5', 'SOS', 'Scheduled Oil Sampling', current_timestamp, 'devadmin', TRUE),
('6', 'CM', 'Customer Master', current_timestamp, 'devadmin', TRUE),
('7', 'ED', 'Equipment Data', current_timestamp, 'devadmin', TRUE),
('8', 'CDDW', 'Caterpillar Digital Data Warehouse (Dealer Data)', current_timestamp, 'devadmin', TRUE),
('9', 'CCDS', 'Cat Connect Digital Services', current_timestamp, 'devadmin', TRUE),
('10', 'SMS', 'Sales Model System', current_timestamp, 'devadmin', TRUE),
('11', 'SAPBW', 'SAP Business Warehouse', current_timestamp, 'devadmin', TRUE),
('12', 'EQPDD', 'Equipment Dealer Data (xml File)', current_timestamp, 'devadmin', TRUE),
('13', 'DSP', 'Dealer Services Portal', current_timestamp, 'devadmin', TRUE),
('14', 'UEQP', 'Unvalidated Equipment', current_timestamp, 'devadmin', TRUE)