CREATE VIEW assets.assoc_strct_dlr AS
	SELECT
		ap.equip_asset_guid,
		ap.party_guid,
		dlr.party_no,
		'3' as party_id_typ_cd,
		pa.assoc_strct
	FROM assets.asset_party ap
	JOIN dbo.dlr dlr on ap.party_guid = dlr.party_guid
	LEFT JOIN LATERAL (
		SELECT json_build_object('associations', json_agg(t2.assoc)) as assoc_strct
		FROM (
			SELECT row_to_json(t) as assoc
			FROM (
				SELECT
					ucid.party_no 	as "ucid",
					ucid.lgl_nm 	as "ucidName",
					dcn.party_no 	as "dcn",
					dcn.lgl_nm 		as "dcnName",
					dlr.party_no 	as "dlr",
					dlr.lgl_nm 		as "dlrName"
				FROM dbo.cust dcn
				JOIN assets.asset_party a			on a.party_guid = dcn.party_guid and ap.equip_asset_guid = a.equip_asset_guid
				LEFT JOIN dbo.party_xref x 			on x.xref_party_id = dcn.party_guid
				LEFT JOIN dbo.cust ucid 			on x.party_guid = ucid.party_guid
				WHERE dlr.party_no = dcn.src_sub_sys_cd
			) t
		) t2
		LIMIT 1
	) pa ON True;

