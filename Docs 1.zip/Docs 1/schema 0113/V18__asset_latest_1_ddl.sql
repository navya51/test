
CREATE VIEW assets.asset_latest AS
	SELECT
        b.party_guid,
		b.party_no,
		b.party_id_typ_cd,
        b.party_id_typ_nm,
		b.lgl_nm as org_lgl_nm,
        b.equip_asset_guid,
        b.assoc_strct,
		b.ser_no,
		b.asset_intrnl_id,
		b.mfr_cd,
		b.slsmdl_and_mdfy_no,
		b.nm as equip_asset_alt_nm,
		b.assoc_nm as equip_asset_party_typ_assoc_name,
        null as prod_fam_icon_url, --still needed
		b.prod_fam_cd,
		b.prod_fam_desc,
        null as asset_icon_url, --still needed
        null as is_conn, --still needed
		null as asset_stat,
		null as asset_stat_cd,
        null as telemtry_dv_typ, --still needed
		null as dv_stat,
		null as dv_stat_cd,
		null as dv_stat_message_timestmp,
		null as dv_stat_universaltimecordd_offset,
        t.loc_src,
		t.loc_reverse_geoloc_adr,
		CAST(ST_SetSRID(ST_Point(t.loc_lat, t.loc_long), 4326) AS GEOGRAPHY) as loc_location,
		t.loc_lat,
		t.loc_long,
		t.loc_message_timestmp,
		t.loc_universaltimecordd_offset,
		t.dist_trav_src,
		t.dist_trav_meas,
		t.dist_trav_message_timestmp,
		t.dist_trav_universaltimecordd_offset,
		t.master_smh_src,
		t.master_smh_meas,
		t.master_smh_message_timestmp,
		t.master_smh_universaltimecordd_offset,
		t.def_src,
		t.def_meas,
		t.def_message_timestmp,
		t.def_universaltimecordd_offset
	FROM assets.asset_base b
-- 	LEFT JOIN LATERAL (
-- 		SELECT
-- 			s.asset_stat,
-- 			s.asset_stat_cd,
-- 			s.dv_stat,
-- 			s.dv_stat_cd,
-- 			s.dv_stat_message_timestmp,
-- 			s.dv_stat_universaltimecordd_offset
-- 		FROM assets.vw_asset_timeline_latest_v1 s
-- 		WHERE b.party_guid = s.party_guid AND b.equip_asset_guid = s.equip_asset_guid
-- 		LIMIT 1
-- 	) s on true
	LEFT JOIN LATERAL (
		SELECT *
		FROM assets.telemetry_latest s
		WHERE b.party_guid = s.party_guid AND b.equip_asset_guid = s.equip_asset_guid
		LIMIT 1
	) t on true;


