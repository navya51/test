INSERT INTO dbo.equip_asset_party_src_assoc_typ
(src_assoc_typ_cd, src_id, assoc_typ_cd, src_assoc_nm, src_assoc_desc, crte_dttm, crte_by_id)
VALUES
('O', '8', '1', 'Owned', 'Party who owns actual asset', current_timestamp, 'devadmin'),
('C', '8', '1', 'Convert from Rent or Lease (same as Owned)', 'Dealer who services asset', current_timestamp, 'devadmin'),
('L', '8', '5', 'Leased', 'Leasing party of asset', current_timestamp, 'devadmin'),
('R', '8', '6', 'Rented', 'Renting party of asset', current_timestamp, 'devadmin'),
('I', '8', '7', 'Inventory', 'Inventory asset', current_timestamp, 'devadmin'),
('X', '8', '8', 'Unknown', 'Unknown', current_timestamp, 'devadmin')

