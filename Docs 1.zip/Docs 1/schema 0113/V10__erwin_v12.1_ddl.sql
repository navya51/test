CREATE TABLE dbo.Telemtry_Current
(
	meas_typ             varchar(60)  NOT NULL ,
	message_id           varchar(40)  NOT NULL ,
	message_timestmp     timestamp  NULL ,
	universaltimecordd_offset integer  NULL ,
	party_guid           varchar(36)  NOT NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	last_updt_dttm       timestamp  NULL ,
	last_updt_by_id      varchar(12)  NULL ,
	equip_asset_guid     varchar(36)  NOT NULL ,
	CONSTRAINT XPKTelemetry_Current PRIMARY KEY (party_guid,equip_asset_guid,meas_typ)
);

CREATE INDEX XIF1Telemetry_Current ON dbo.Telemtry_Current
(
	equip_asset_guid ASC
);

CREATE TABLE dbo.Telemtry_Daily
(
	meas_typ             varchar(60)  NOT NULL ,
	asset_locl_date      date  NOT NULL ,
	message_timestmp     timestamp  NULL ,
	message_id           varchar(40)  NOT NULL ,
	universaltimecordd_offset integer  NULL ,
	last_updt_dttm       timestamp  NULL ,
	last_updt_by_id      varchar(12)  NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	equip_asset_guid     varchar(36)  NOT NULL ,
	CONSTRAINT XPKTelemetry_Daily PRIMARY KEY (equip_asset_guid,meas_typ,asset_locl_date)
);

CREATE INDEX XIF1Telemetry_Daily ON dbo.Telemtry_Daily
(
	equip_asset_guid ASC
);


CREATE TABLE dbo.Telemtry_Dtl
(
	blk_typ              varchar(60)  NOT NULL ,
	message_id           varchar(40)  NOT NULL ,
	message_timestmp     timestamp  NOT NULL ,
	universaltimecordd_offset integer  NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	last_updt_dttm       timestamp  NULL ,
	last_updt_by_id      varchar(12)  NULL ,
	equip_asset_guid     varchar(36)  NOT NULL ,
	CONSTRAINT XPKTelemetry_Detail PRIMARY KEY (equip_asset_guid,blk_typ,message_timestmp)
);

CREATE INDEX XIF1Telemetry_Detail ON dbo.Telemtry_Dtl
(
	equip_asset_guid ASC
);

CREATE TABLE dbo.Asset_Diesel_Exhaust_Fluid_Dtl
(
	diesel_exhaust_fluid_lvl double precision  NULL ,
	diesel_exhaust_fluid_cum double precision  NULL ,
	LIKE dbo.Telemtry_Dtl
	INCLUDING INDEXES
)
INHERITS (dbo.Telemtry_Dtl);

CREATE TABLE dbo.Diesel_Exhaust_Fluid_Current
(
	meas  double precision  NULL ,
	LIKE dbo.Telemtry_Current
	INCLUDING INDEXES
)
INHERITS (dbo.Telemtry_Current);

CREATE TABLE dbo.Asset_Fuel_Hrs_Current
(
	meas                 double precision  NULL ,
	LIKE dbo.Telemtry_Current
	INCLUDING INDEXES
)
INHERITS (dbo.Telemtry_Current);

CREATE TABLE dbo.Diesel_Exhaust_Fluid_Lvl_Current
(
	meas                 double precision  NULL ,
	LIKE dbo.Telemtry_Current
	INCLUDING INDEXES
)
INHERITS (dbo.Telemtry_Current);

CREATE TABLE dbo.Fuel_Lvl_Current
(
	meas                 double precision  NULL ,
	LIKE dbo.Telemtry_Current
	INCLUDING INDEXES
)
INHERITS (dbo.Telemtry_Current);

CREATE TABLE dbo.Generator_Power_Current
(
	meas                 double precision  NOT NULL ,
	LIKE dbo.Telemtry_Current
	INCLUDING INDEXES
)
INHERITS (dbo.Telemtry_Current);

CREATE TABLE dbo.Generator_Power_Daily
(
	meas                 double precision  NOT NULL ,
	LIKE dbo.Telemtry_Daily
	INCLUDING INDEXES
)
INHERITS (dbo.Telemtry_Daily);

CREATE TABLE dbo.Generator_Reactv_Power_Current
(
	meas                 double precision  NOT NULL ,
	LIKE dbo.Telemtry_Current
	INCLUDING INDEXES
)
INHERITS (dbo.Telemtry_Current);

CREATE TABLE dbo.Fault_Cd_Dtl
(
	message_typ_cd       varchar(12)  NOT NULL ,
	fault_cd             varchar(12)  NOT NULL ,
	fault_desc_guid      varchar(36)  NULL ,
	fault_id             varchar(40)  NULL ,
	evnt_id              varchar(40)  NULL ,
	typ_id               varchar(40)  NULL ,
	cmpnt_id             varchar(40)  NULL ,
	suspectparameterno   double precision  NULL ,
	fault_mode_ind       boolean  NULL ,
	fault_desc           varchar(255)  NULL ,
	fault_lvl            integer  NULL ,
	occurence_cnt        integer  NULL ,
	electrctlunit_id     varchar(40)  NULL ,
	electrctlunit_desc   varchar(255)  NULL ,
	fault_svc_meter_hrs  double precision  NULL ,
	trusted_master_svc_meter_hrs double precision  NULL ,
	opr_annunciation_stat varchar(60)  NULL ,
	universaltimecordd_ind boolean  NULL ,
	lamp_stat            varchar(60)  NULL ,
	lamp_flash_ind       boolean  NULL ,
	vims_file_nm         varchar(60)  NULL ,
	vims_evnt_chan_id    varchar(40)  NULL ,
	vims_evnt_frst_val   double precision  NULL ,
	vims_evnt_worst_val  double precision  NULL ,
	vims_evnt_actuate_lmt double precision  NULL ,
	vims_evnt_frst_acknowledged_time double precision  NULL ,
	vims_evnt_time_uom   double precision  NULL ,
	vims_evnt_acknowledge_cnt integer  NULL ,
	vims_evnt_dur        double precision  NULL ,
	vims_evnt_actv_ind   boolean  NULL ,
	vims_evnt_legacy_typ_id varchar(40)  NULL ,
	vims_evnt_lmt_uom    varchar(60)  NULL ,
	vims_evnt_stat       varchar(60)  NULL ,
	vims_evnt_stat_ind   boolean  NULL ,
	vims_evnt_snapshot_ind boolean  NULL ,
	vims_evnt_deactuate_lmt double precision  NULL ,
	LIKE dbo.Telemtry_Dtl
	INCLUDING INDEXES
)
INHERITS (dbo.Telemtry_Dtl);

CREATE TABLE dbo.Asset_Fuel_Dtl
(
	idle_hrs             double precision  NULL ,
	idle_fuel            double precision  NULL ,
	fuel                 double precision  NULL ,
	eng_fuel             double precision  NULL ,
	eng_start_cnt        double precision  NULL ,
	eng_revolution_cnt   double precision  NULL ,
	fuel_max             double precision  NULL ,
	LIKE dbo.Telemtry_Dtl
	INCLUDING INDEXES
)
INHERITS (dbo.Telemtry_Dtl);

CREATE TABLE dbo.Asset_Fuel_Current
(
	meas                 double precision  NULL ,
	LIKE dbo.Telemtry_Current
	INCLUDING INDEXES
)
INHERITS (dbo.Telemtry_Current);

CREATE TABLE dbo.Asset_Idle_Fuel_Current
(
	meas                 double precision  NULL ,
	LIKE dbo.Telemtry_Current
	INCLUDING INDEXES
)
INHERITS (dbo.Telemtry_Current);

CREATE TABLE dbo.Distance_Traveled_Current
(
	meas                 double precision  NULL ,
	LIKE dbo.Telemtry_Current
	INCLUDING INDEXES
)
INHERITS (dbo.Telemtry_Current);

CREATE TABLE dbo.Fuel_Lvl_Dtl
(
	fuel_lvl             double precision  NULL ,
	electrctlunit_id     varchar(12)  NOT NULL ,
	electrctlunit_desc   varchar(255)  NULL ,
	svc_meter_hr         double precision  NULL ,
	LIKE dbo.Telemtry_Dtl
	INCLUDING INDEXES
)
INHERITS (dbo.Telemtry_Dtl);

CREATE TABLE dbo.Generator_Utilization_Dtl
(
	power_meas           double precision  NULL ,
	reactv_power_meas    double precision  NULL ,
	electrctlunit_id     varchar(12)  NOT NULL ,
	electrctlunit_desc   varchar(255)  NULL ,
	LIKE dbo.Telemtry_Dtl
	INCLUDING INDEXES
)
INHERITS (dbo.Telemtry_Dtl);

CREATE TABLE dbo.Idle_Ind_Current
(
	meas                 boolean  NULL ,
	LIKE dbo.Telemtry_Current
	INCLUDING INDEXES
)
INHERITS (dbo.Telemtry_Current);

CREATE TABLE dbo.Loc_Current
(
	lat                  double precision  NULL ,
	long                 double precision  NULL ,
	heading              double precision  NULL ,
	grnd_speed           double precision  NULL ,
	temperature          double precision  NULL ,
	altd                 double precision  NULL ,
	reverse_geoloc_adr   varchar(255)  NULL ,
	china_prov_cd        varchar(12)  NOT NULL ,
	gps_radio_src_id     varchar(40)  NOT NULL ,
	loc_accuracy         double precision  NULL ,
	last_good_timestmp   timestamp  NULL ,
	gps_stat             varchar(40)  NOT NULL ,
	gps_fix_not_available_ind boolean  NULL ,
	valid_gps_ind        boolean  NULL ,
	stat_rsn_cd          varchar(12)  NOT NULL ,
	electrctlunit_id     varchar(40)  NOT NULL ,
	electrctlunit_desc   varchar(255)  NULL ,
	adr                  varchar(40)  NULL ,
	overridden_ind       boolean  NULL ,
	china_cordd_id       varchar(40)  NOT NULL ,
	signal_strength      double precision  NULL ,
	LIKE dbo.Telemtry_Current
	INCLUDING INDEXES
)
INHERITS (dbo.Telemtry_Current);

CREATE TABLE dbo.Loc_Dtl
(
	lat                  double precision  NULL ,
	long                 double precision  NULL ,
	overridden_ind       boolean  NULL ,
	heading              double precision  NULL ,
	grnd_speed           double precision  NULL ,
	temperature          double precision  NULL ,
	altd                 double precision  NULL ,
	reverse_geoloc_adr   varchar(255)  NULL ,
	china_cordd_id       varchar(40)  NOT NULL ,
	china_prov_cd        varchar(12)  NOT NULL ,
	gps_radio_src_id     varchar(40)  NOT NULL ,
	loc_accuracy         double precision  NULL ,
	last_good_timestmp   timestamp  NULL ,
	signal_strength      double precision  NULL ,
	gps_stat             varchar(40)  NOT NULL ,
	gps_fix_not_available_ind boolean  NULL ,
	valid_gps_ind        boolean  NULL ,
	stat_rsn_cd          varchar(12)  NOT NULL ,
	adr                  varchar(40)  NULL ,
	electrctlunit_id     varchar(40)  NOT NULL ,
	electrctlunit_desc   varchar(255)  NULL ,
	LIKE dbo.Telemtry_Dtl
	INCLUDING INDEXES
)
INHERITS (dbo.Telemtry_Dtl);

CREATE TABLE dbo.Master_Svc_Meter_Hr_Current
(
	electrctlunit_id     varchar(40)  NOT NULL ,
	electrctlunit_desc   varchar(255)  NULL ,
	meas                 double precision  NULL ,
	LIKE dbo.Telemtry_Current
	INCLUDING INDEXES
)
INHERITS (dbo.Telemtry_Current);

CREATE TABLE dbo.Master_Svc_Meter_Hr_Dtl
(
	electrctlunit_id     varchar(40)  NOT NULL ,
	electrctlunit_desc   varchar(255)  NULL ,
	master_svc_meter_hr  double precision  NULL ,
	LIKE dbo.Telemtry_Dtl
	INCLUDING INDEXES
)
INHERITS (dbo.Telemtry_Dtl);

CREATE TABLE dbo.Svc_Meter_Hr_Dtl
(
	electrctlunit_id     varchar(40)  NOT NULL ,
	electrctlunit_desc   varchar(255)  NULL ,
	svc_meter_hr         double precision  NULL ,
	LIKE dbo.Telemtry_Dtl
	INCLUDING INDEXES
)
INHERITS (dbo.Telemtry_Dtl);

CREATE TABLE dbo.Master_Svc_Meter_Hr_Daily
(
	meas                 double precision  NULL ,
	electrctlunit_id     varchar(40)  NOT NULL ,
	electrctlunit_desc   varchar(255)  NULL ,
	LIKE dbo.Telemtry_Daily
	INCLUDING INDEXES
)
INHERITS (dbo.Telemtry_Daily);

CREATE TABLE dbo.Loc_Daily
(
	lat                  double precision  NULL ,
	long                 double precision  NULL ,
	heading              double precision  NULL ,
	grnd_speed           double precision  NULL ,
	temperature          double precision  NULL ,
	altd                 double precision  NULL ,
	reverse_geoloc_adr   varchar(255)  NULL ,
	china_prov_cd        varchar(12)  NOT NULL ,
	gps_radio_src_id     varchar(40)  NOT NULL ,
	loc_accuracy         double precision  NULL ,
	last_good_timestmp   timestamp  NULL ,
	gps_stat             varchar(40)  NOT NULL ,
	gps_fix_not_available_ind boolean  NULL ,
	valid_gps_ind        boolean  NULL ,
	stat_rsn_cd          varchar(12)  NOT NULL ,
	electrctlunit_id     varchar(40)  NOT NULL ,
	electrctlunit_desc   varchar(255)  NULL ,
	adr                  varchar(40)  NULL ,
	overridden_ind       boolean  NULL ,
	china_cordd_id       varchar(40)  NOT NULL ,
	signal_strength      double precision  NULL ,
	LIKE dbo.Telemtry_Daily
	INCLUDING INDEXES
)
INHERITS (dbo.Telemtry_Daily);

CREATE TABLE dbo.Asset_Idle_Fuel_Daily
(
	meas                 double precision  NULL ,
	LIKE dbo.Telemtry_Daily
	INCLUDING INDEXES
)
INHERITS (dbo.Telemtry_Daily);

CREATE TABLE dbo.Asset_Fuel_Hrs_Daily
(
	meas                 double precision  NULL ,
	LIKE dbo.Telemtry_Daily
	INCLUDING INDEXES
)
INHERITS (dbo.Telemtry_Daily);

CREATE TABLE dbo.Asset_Fuel_Daily
(
	meas                 double precision  NULL ,
	LIKE dbo.Telemtry_Daily
	INCLUDING INDEXES
)
INHERITS (dbo.Telemtry_Daily);

CREATE TABLE dbo.Asset_Idle_Hrs_Daily
(
	meas                 double precision  NULL ,
	LIKE dbo.Telemtry_Daily
	INCLUDING INDEXES
)
INHERITS (dbo.Telemtry_Daily);

CREATE TABLE dbo.Asset_Start_Mode_Dtl
(
	state_id             varchar(40)  NOT NULL ,
	mch_start_trigger_stat varchar(60)  NOT NULL ,
	unknown_stat_ind     boolean  NULL ,
	ota_command_ind      boolean  NULL ,
	svc_tool_restr_command_ind boolean  NULL ,
	gps_antenna_discnect_time_expired_ind boolean  NULL ,
	telematics_antenna_discnect_timer_expired_ind boolean  NULL ,
	cnect_to_back_ofc_timer_expired_ind boolean  NULL ,
	tamper_resolved_ind  boolean  NULL ,
	tamper_uninstled_ind boolean  NULL ,
	LIKE dbo.Telemtry_Dtl
	INCLUDING INDEXES
)
INHERITS (dbo.Telemtry_Dtl);

CREATE TABLE dbo.Diesel_Exhaust_Fluid_Daily
(
	meas                 double precision  NULL ,
	LIKE dbo.Telemtry_Daily
	INCLUDING INDEXES
)
INHERITS (dbo.Telemtry_Daily);

CREATE TABLE dbo.Diesel_Exhaust_Fluid_Lvl_Daily
(
	meas                 double precision  NULL ,
	LIKE dbo.Telemtry_Daily
	INCLUDING INDEXES
)
INHERITS (dbo.Telemtry_Daily);

CREATE TABLE dbo.Distance_Traveled_Daily
(
	meas                 double precision  NULL ,
	LIKE dbo.Telemtry_Daily
	INCLUDING INDEXES
)
INHERITS (dbo.Telemtry_Daily);

CREATE TABLE dbo.Fence_Dtl
(
	trigger_id           varchar(40)  NULL ,
	trigger_desc         varchar(255)  NULL ,
	fence_id             varchar(40)  NOT NULL ,
	offboard_fence_id    varchar(40)  NULL ,
	offboard_client_fence_id varchar(40)  NULL ,
	offboard_client_id   varchar(40)  NULL ,
	LIKE dbo.Telemtry_Dtl
	INCLUDING INDEXES
)
INHERITS (dbo.Telemtry_Dtl);

CREATE TABLE dbo.Fuel_Lvl_Daily
(
	meas                 double precision  NULL ,
	LIKE dbo.Telemtry_Daily
	INCLUDING INDEXES
)
INHERITS (dbo.Telemtry_Daily);

CREATE TABLE dbo.Generator_Reactv_Power_Daily
(
	meas                 double precision  NOT NULL ,
	LIKE dbo.Telemtry_Daily
	INCLUDING INDEXES
)
INHERITS (dbo.Telemtry_Daily);

CREATE TABLE dbo.Mch_Idle_Start_Stop_Dtl
(
	electrctlunit_id     varchar(40)  NOT NULL ,
	electronctlunit_desc varchar(255)  NULL ,
	idle_ind             boolean  NULL ,
	trigger_chg_universaltimecordd_timestmp timestamp  NULL ,
	LIKE dbo.Telemtry_Dtl
	INCLUDING INDEXES
)
INHERITS (dbo.Telemtry_Dtl);

CREATE TABLE dbo.Odmtr_Dtl
(
	distance_traveled    double precision  NULL ,
	LIKE dbo.Telemtry_Dtl
	INCLUDING INDEXES
)
INHERITS (dbo.Telemtry_Dtl);

CREATE TABLE dbo.Rapid_Rptg_Locs_Dtl
(
	lat                  double precision  NULL ,
	long                 double precision  NULL ,
	rapid_rptg_timestmp  timestamp  NULL ,
	overridden_ind       boolean  NULL ,
	heading              double precision  NULL ,
	grnd_speed           double precision  NULL ,
	temperature          double precision  NULL ,
	altd                 double precision  NULL ,
	reverse_geoloc_adr   varchar(255)  NULL ,
	china_cordd_id       varchar(40)  NOT NULL ,
	china_prov_cd        varchar(12)  NOT NULL ,
	gps_radio_src_id     varchar(40)  NOT NULL ,
	loc_accuracy         double precision  NULL ,
	last_good_timestmp   timestamp  NULL ,
	signal_strength      double precision  NULL ,
	gps_stat             varchar(40)  NOT NULL ,
	gps_fix_not_available_ind boolean  NULL ,
	valid_gps_ind        boolean  NULL ,
	stat_rsn_cd          varchar(12)  NOT NULL ,
	electrctlunit_id     varchar(40)  NOT NULL ,
	electrctlunit_desc   varchar(255)  NULL ,
	adr                  varchar(40)  NULL ,
	LIKE dbo.Telemtry_Dtl
	INCLUDING INDEXES
)
INHERITS (dbo.Telemtry_Dtl);

CREATE TABLE dbo.Start_Stop_Daily
(
	start_timestmp       timestamp  NOT NULL ,
	end_timestmp         timestamp  NULL ,
	stat                 varchar(60)  NOT NULL ,
	ready_to_run_ind     boolean  NULL ,
	eng_ready_to_run_hex varchar(40)  NULL ,
	opr_id               varchar(40)  NULL ,
	opr_typ              varchar(12)  NULL ,
	opr_nm               varchar(60)  NULL ,
	electrctlunit_id     varchar(40)  NOT NULL ,
	electrctlunit_desc   varchar(255)  NULL ,
	trigger_id           varchar(40)  NULL ,
	trigger_desc         varchar(255)  NULL ,
	LIKE dbo.Telemtry_Daily
	INCLUDING INDEXES
)
INHERITS (dbo.Telemtry_Daily);

CREATE TABLE dbo.Start_Stop_Dtl
(
	start_timestmp       timestamp  NOT NULL ,
	end_timestmp         timestamp  NULL ,
	stat                 varchar(60)  NOT NULL ,
	ready_to_run_ind     boolean  NULL ,
	eng_ready_to_run_hex varchar(40)  NULL ,
	opr_id               varchar(40)  NULL ,
	opr_typ              varchar(12)  NULL ,
	opr_nm               varchar(60)  NULL ,
	electrctlunit_id     varchar(40)  NOT NULL ,
	electrctlunit_desc   varchar(255)  NULL ,
	trigger_id           varchar(40)  NULL ,
	trigger_desc         varchar(255)  NULL ,
	LIKE dbo.Telemtry_Dtl
	INCLUDING INDEXES
)
INHERITS (dbo.Telemtry_Dtl);

CREATE TABLE dbo.Telemtry_Rptg_Daily
(
	gateway_received_timestmp timestamp  NULL ,
	LIKE dbo.Telemtry_Daily
	INCLUDING INDEXES
)
INHERITS (dbo.Telemtry_Daily);

CREATE TABLE dbo.Asset_Idle_Hrs_Current
(
	meas                 double precision  NULL ,
	LIKE dbo.Telemtry_Current
	INCLUDING INDEXES
)
INHERITS (dbo.Telemtry_Current);
