INSERT INTO dbo.equip_asset_party_assoc_typ
(assoc_typ_cd, assoc_nm, assoc_desc, crte_dttm, crte_by_id)
VALUES
('1', 'Owning Party', 'Party who owns actual asset', current_timestamp, 'devadmin'),
('2', 'Servicing Dealer', 'Dealer who services asset', current_timestamp, 'devadmin'),
('3', 'Sold by Dealer', 'Dealer who sold asset', current_timestamp, 'devadmin'),
('4', 'Related Dealer', 'Related dealer to asset', current_timestamp, 'devadmin'),
('5', 'Leasing Party', 'Leasing party of asset', current_timestamp, 'devadmin'),
('6', 'Renting Party', 'Renting party of asset', current_timestamp, 'devadmin'),
('7', 'Inventory', 'Inventory asset', current_timestamp, 'devadmin'),
('8', 'Unknown', 'Unknown', current_timestamp, 'devadmin'),
('9', 'Others', 'Holder for new association type code', current_timestamp, 'devadmin')

