CREATE SCHEMA IF NOT EXISTS dbo;

CREATE SCHEMA IF NOT EXISTS assets;

ALTER TABLE dbo.party
    DROP CONSTRAINT IF EXISTS XAK2Party;

ALTER TABLE dbo.party
    DROP CONSTRAINT IF EXISTS XAK3Party;

ALTER TABLE dbo.Party
ADD CONSTRAINT XAK2Party UNIQUE (src_sub_sys_cd,party_guid);

ALTER TABLE dbo.Party
ADD CONSTRAINT XAK3Party UNIQUE (party_no,party_guid);

CREATE TABLE dbo.Equip_Asset_Ownshp_Master
(
	assoc_end_dttm       timestamp  NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(12)  NULL ,
	assoc_beg_dttm       timestamp  NOT NULL ,
	equip_asset_master_guid varchar(36)  NOT NULL ,
	cust_master_guid     varchar(36)  NOT NULL ,
	cust_master_rev_no   varchar(20)  NOT NULL ,
	equip_asset_master_rev_no varchar(20)  NOT NULL ,
	CONSTRAINT XPKEquipment_Asset_Ownership_Master PRIMARY KEY (equip_asset_master_guid,equip_asset_master_rev_no,cust_master_guid,cust_master_rev_no,assoc_beg_dttm)
);

CREATE INDEX XIF1Equipment_Asset_Ownership_Master ON dbo.Equip_Asset_Ownshp_Master
(
	cust_master_guid ASC,
	cust_master_rev_no ASC
);

CREATE INDEX XIF2Equipment_Asset_Ownership_Master ON dbo.Equip_Asset_Ownshp_Master
(
	equip_asset_master_guid ASC,
	equip_asset_master_rev_no ASC
);

CREATE TABLE dbo.Equip_Insp
(
	insp_no              integer  NOT NULL ,
	insp_form_nm         varchar(100)  NOT NULL ,
	svc_meter_read       integer  NULL ,
	insp_form_typ_cd     varchar(40)  NULL ,
	loc_lat		         double precision  NULL ,
	loc_long	         double precision  NULL ,
	insp_opened_date     timestamp  NULL ,
	insp_cmnts           text  NULL ,
	equip_asset_guid     varchar(36)  NOT NULL ,
	ser_no               varchar(40)  NOT NULL ,
	wrk_ord_id           varchar(40)  NOT NULL ,
	cust_party_guid      varchar(36)  NULL ,
	svc_meter_unit_of_measure_cd varchar(12)  NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(12)  NULL ,
	insp_form_no         integer  NULL ,
	owning_org_nm        varchar(160)  NULL ,
	overall_ratg_cd      varchar(40)  NULL ,
	loc_desc             varchar(255)  NULL ,
	insp_cmplt_date      timestamp  NULL ,
	insp_loc_utc_offset_no double precision  NULL ,
	loc_altd             double precision  NULL ,
	asgn_by_catrecid     varchar(40)  NOT NULL ,
	cmpltd_by_catrecid   varchar(40)  NOT NULL ,
	sales_mdl_nm         varchar(60)  NOT NULL ,
	prod_fam_nm          varchar(60)  NOT NULL ,
	equip_no             varchar(40)  NOT NULL ,
	score_answer_txt     varchar(2000)  NULL ,
	max_score_no         integer  NULL ,
	score_overall_ratg_cd varchar(40)  NULL ,
	user_score_no        integer  NULL ,
	affirmative_response_typ_cd varchar(40)  NULL ,
	init_ratg            integer  NULL ,
	pctage_no            double precision  NULL ,
	uom_abr              varchar(10)  NULL ,
	CONSTRAINT XPKEquipment_Inspection PRIMARY KEY (insp_no)
);

CREATE INDEX XIF1Equipment_Inspection ON dbo.Equip_Insp
(
	equip_asset_guid ASC
);

CREATE INDEX XIF3Equipment_Inspection ON dbo.Equip_Insp
(
	cust_party_guid ASC
);

CREATE INDEX XIF4Equipment_Inspection ON dbo.Equip_Insp
(
	svc_meter_unit_of_measure_cd ASC
);

CREATE TABLE dbo.Asset_Stat_Supprted_Dv
(
	dv_typ               varchar(60)  NOT NULL ,
	asset_stat_supprt_cd varchar(40)  NULL ,
	CONSTRAINT XPKAsset_Stat_Supprted_DV PRIMARY KEY (dv_typ)
);

ALTER TABLE dbo.Equip_Insp RENAME COLUMN loc_lat TO loc_latitude;

ALTER TABLE dbo.Equip_Insp RENAME COLUMN loc_long TO loc_longitude;

ALTER TABLE dbo.Equip_Insp DROP COLUMN uom_abr;

ALTER TABLE dbo.equip_asset_subscrp ALTER COLUMN subscrp_nm TYPE VARCHAR(2000);

ALTER TABLE dbo.equip_asset_subscrp ALTER COLUMN subscrp_cancel_rsn_nm TYPE VARCHAR(200);

ALTER TABLE dbo.equip_asset_subscrp ALTER COLUMN catalog_app_nm TYPE VARCHAR(100);

ALTER TABLE dbo.equip_asset_subscrp ALTER COLUMN src_dlr_cust_no TYPE VARCHAR(40);

ALTER TABLE dbo.fluid_smpl_interpretation ADD COLUMN overall_interpretation_svrty_cd VARCHAR(12);

ALTER TABLE dbo.equip_insp_ctgry ADD COLUMN insp_no INTEGER;

ALTER TABLE dbo.insp_signoffs ADD COLUMN insp_no INTEGER;

ALTER TABLE dbo.equip_insp_questions ADD COLUMN insp_no INTEGER;

ALTER TABLE dbo.insp_attachment ADD COLUMN insp_no INTEGER;

-- TSF Messages Changes

DROP TABLE IF EXISTS dbo.Daily_Telemtry_Message;

DROP TABLE IF EXISTS dbo.Asset_Timeln;

DROP TABLE IF EXISTS dbo.Telemtry_Messages;

DROP TABLE IF EXISTS dbo.Subscrp_Typ;

DROP TABLE IF EXISTS dbo.Subscrp_Cancel_Rsn;

DROP TABLE IF EXISTS dbo.Subscrp_Src_App;

ALTER TABLE dbo.Telemtry_Daily RENAME COLUMN message_timestmp TO message_dttm;

ALTER TABLE dbo.Telemtry_Daily RENAME COLUMN universaltimecordd_offset TO utc_offset;

ALTER TABLE dbo.Telemtry_Daily RENAME COLUMN last_updt_dttm TO updt_dttm;

ALTER TABLE dbo.Telemtry_Daily RENAME COLUMN last_updt_by_id TO updt_by_id;

ALTER TABLE dbo.Telemtry_Current RENAME COLUMN message_timestmp TO message_dttm;

ALTER TABLE dbo.Telemtry_Current RENAME COLUMN universaltimecordd_offset TO utc_offset;

ALTER TABLE dbo.Telemtry_Current RENAME COLUMN last_updt_dttm TO updt_dttm;

ALTER TABLE dbo.Telemtry_Current RENAME COLUMN last_updt_by_id TO updt_by_id;

ALTER TABLE dbo.Telemtry_Dtl RENAME COLUMN message_timestmp TO message_dttm;

ALTER TABLE dbo.Telemtry_Dtl RENAME COLUMN universaltimecordd_offset TO utc_offset;

ALTER TABLE dbo.Telemtry_Dtl RENAME COLUMN last_updt_dttm TO updt_dttm;

ALTER TABLE dbo.Telemtry_Dtl RENAME COLUMN last_updt_by_id TO updt_by_id;

ALTER TABLE dbo.Master_Svc_Meter_Hr_Daily RENAME COLUMN electrctlunit_id TO ecu_id;

ALTER TABLE dbo.Master_Svc_Meter_Hr_Daily RENAME COLUMN electrctlunit_desc TO ecu_desc;

ALTER TABLE dbo.Master_Svc_Meter_Hr_Current RENAME COLUMN electrctlunit_id TO ecu_id;

ALTER TABLE dbo.Master_Svc_Meter_Hr_Current RENAME COLUMN electrctlunit_desc TO ecu_desc;

ALTER TABLE dbo.Loc_Current RENAME COLUMN lat TO latitude;

ALTER TABLE dbo.Loc_Current RENAME COLUMN long TO longitude;

ALTER TABLE dbo.Loc_Current RENAME COLUMN last_good_timestmp TO last_good_dttm;

ALTER TABLE dbo.Loc_Current RENAME COLUMN electrctlunit_id TO ecu_id;

ALTER TABLE dbo.Loc_Current RENAME COLUMN electrctlunit_desc TO ecu_desc;

ALTER TABLE dbo.Master_Svc_Meter_Hr_Dtl RENAME COLUMN electrctlunit_id TO ecu_id;

ALTER TABLE dbo.Master_Svc_Meter_Hr_Dtl RENAME COLUMN electrctlunit_desc TO ecu_desc;

ALTER TABLE dbo.Master_Svc_Meter_Hr_Dtl RENAME COLUMN master_svc_meter_hr TO master_svc_meter_hr_tot;

ALTER TABLE dbo.Loc_Dtl RENAME COLUMN lat TO latitude;

ALTER TABLE dbo.Loc_Dtl RENAME COLUMN long TO longitude;

ALTER TABLE dbo.Loc_Dtl RENAME COLUMN last_good_timestmp TO last_good_dttm;

ALTER TABLE dbo.Loc_Dtl RENAME COLUMN electrctlunit_id TO ecu_id;

ALTER TABLE dbo.Loc_Dtl RENAME COLUMN electrctlunit_desc TO ecu_desc;

ALTER TABLE dbo.Odmtr_Dtl RENAME COLUMN distance_traveled TO distance_traveled_tot;

ALTER TABLE dbo.Asset_Fuel_Dtl RENAME COLUMN idle_hrs TO idle_hrs_tot;

ALTER TABLE dbo.Asset_Fuel_Dtl RENAME COLUMN idle_fuel TO idle_fuel_tot;

ALTER TABLE dbo.Asset_Fuel_Dtl RENAME COLUMN fuel TO fuel_tot;

ALTER TABLE dbo.Asset_Fuel_Dtl RENAME COLUMN eng_fuel TO eng_fuel_tot;

ALTER TABLE dbo.Asset_Fuel_Dtl RENAME COLUMN eng_start_cnt TO eng_start_tot;

ALTER TABLE dbo.Asset_Fuel_Dtl RENAME COLUMN eng_revolution_cnt TO eng_revolution_tot;

ALTER TABLE dbo.Asset_Fuel_Dtl RENAME COLUMN fuel_max TO fuel_max_tot;

ALTER TABLE dbo.Start_Stop_Dtl RENAME COLUMN start_timestmp TO start_dttm;

ALTER TABLE dbo.Start_Stop_Dtl RENAME COLUMN end_timestmp TO stop_dttm;

ALTER TABLE dbo.Start_Stop_Dtl RENAME COLUMN electrctlunit_id TO ecu_id;

ALTER TABLE dbo.Start_Stop_Dtl RENAME COLUMN electrctlunit_desc TO ecu_desc;

ALTER TABLE dbo.Mch_Idle_Start_Stop_Dtl RENAME COLUMN electrctlunit_id TO ecu_id;

ALTER TABLE dbo.Mch_Idle_Start_Stop_Dtl RENAME COLUMN electronctlunit_desc TO ecu_desc;

ALTER TABLE dbo.Mch_Idle_Start_Stop_Dtl RENAME COLUMN trigger_chg_universaltimecordd_timestmp TO trigger_chg_utc_dttm;

ALTER TABLE dbo.Fuel_Lvl_Dtl RENAME COLUMN electrctlunit_id TO ecu_id;

ALTER TABLE dbo.Fuel_Lvl_Dtl RENAME COLUMN electrctlunit_desc TO ecu_desc;

ALTER TABLE dbo.Rapid_Rptg_Locs_Dtl RENAME COLUMN lat TO latitude;

ALTER TABLE dbo.Rapid_Rptg_Locs_Dtl RENAME COLUMN long TO longitude;

ALTER TABLE dbo.Rapid_Rptg_Locs_Dtl RENAME COLUMN rapid_rptg_timestmp TO rapid_rptg_dttm;

ALTER TABLE dbo.Rapid_Rptg_Locs_Dtl RENAME COLUMN last_good_timestmp TO last_good_dttm;

ALTER TABLE dbo.Rapid_Rptg_Locs_Dtl RENAME COLUMN electrctlunit_id TO ecu_id;

ALTER TABLE dbo.Rapid_Rptg_Locs_Dtl RENAME COLUMN electrctlunit_desc TO ecu_desc;

ALTER TABLE dbo.Svc_Meter_Hr_Dtl RENAME COLUMN electrctlunit_id TO ecu_id;

ALTER TABLE dbo.Svc_Meter_Hr_Dtl RENAME COLUMN electrctlunit_desc TO ecu_desc;

ALTER TABLE dbo.Svc_Meter_Hr_Dtl RENAME COLUMN svc_meter_hr TO svc_meter_hr_tot;

ALTER TABLE dbo.Generator_Utilization_Dtl RENAME COLUMN power_meas TO power_tot;

ALTER TABLE dbo.Generator_Utilization_Dtl RENAME COLUMN reactv_power_meas TO reactv_power_tot;

ALTER TABLE dbo.Generator_Utilization_Dtl RENAME COLUMN electrctlunit_id TO ecu_id;

ALTER TABLE dbo.Generator_Utilization_Dtl RENAME COLUMN electrctlunit_desc TO ecu_desc;

ALTER TABLE dbo.Asset_Diesel_Exhaust_Fluid_Dtl RENAME COLUMN diesel_exhaust_fluid_cum TO diesel_exhaust_fluid_tot;

ALTER TABLE dbo.Telemtry_Rptg_Daily RENAME COLUMN gateway_received_timestmp TO gateway_received_dttm;

ALTER TABLE dbo.Loc_Daily RENAME COLUMN lat TO latitude;

ALTER TABLE dbo.Loc_Daily RENAME COLUMN long TO longitude;

ALTER TABLE dbo.Loc_Daily RENAME COLUMN last_good_timestmp TO last_good_dttm;

ALTER TABLE dbo.Loc_Daily RENAME COLUMN electrctlunit_id TO ecu_id;

ALTER TABLE dbo.Loc_Daily RENAME COLUMN electrctlunit_desc TO ecu_desc;

ALTER TABLE dbo.Start_Stop_Daily RENAME COLUMN start_timestmp TO start_dttm;

ALTER TABLE dbo.Start_Stop_Daily RENAME COLUMN end_timestmp TO stop_dttm;

ALTER TABLE dbo.Start_Stop_Daily RENAME COLUMN electrctlunit_id TO ecu_id;

ALTER TABLE dbo.Start_Stop_Daily RENAME COLUMN electrctlunit_desc TO ecu_desc;

ALTER TABLE dbo.Idle_Ind_Current RENAME COLUMN meas TO idle_ind;

ALTER TABLE dbo.Fault_Cd_Dtl RENAME COLUMN evnt_id TO evnt_id_cd;

ALTER TABLE dbo.Fault_Cd_Dtl RENAME COLUMN cmpnt_id TO cmpnt_id_cd;

ALTER TABLE dbo.Fault_Cd_Dtl RENAME COLUMN electrctlunit_id TO ecu_id;

ALTER TABLE dbo.Fault_Cd_Dtl RENAME COLUMN electrctlunit_desc TO ecu_desc;

ALTER TABLE dbo.Fault_Cd_Dtl RENAME COLUMN suspectparameterno TO suspect_parameter_no_cd;

ALTER TABLE dbo.Fault_Cd_Dtl RENAME COLUMN fault_mode_ind TO fault_mode_ind_cd;

ALTER TABLE dbo.Fault_Cd_Dtl RENAME COLUMN universaltimecordd_ind TO utc_ind;

ALTER TABLE dbo.Fault_Cd_Dtl RENAME COLUMN vims_evnt_stat_ind TO vims_evnt_stat_ind_cd;

ALTER TABLE dbo.Fault_Cd_Dtl ALTER COLUMN suspect_parameter_no_cd TYPE VARCHAR(40);

ALTER TABLE dbo.Fault_Cd_Dtl ALTER COLUMN vims_evnt_stat_ind_cd TYPE VARCHAR(40);

ALTER TABLE dbo.Fault_Cd_Dtl ALTER COLUMN fault_mode_ind_cd TYPE VARCHAR(40);

-- Assets schema

DROP TABLE IF EXISTS assets.asset_timeline;

CREATE TABLE assets.Asset_Timeln
(
	party_guid           varchar(36)  NOT NULL ,
	evnt_guid            varchar(36)  NOT NULL ,
	equip_asset_guid     varchar(36)  NOT NULL ,
	party_no             varchar(40)  NOT NULL ,
	evnt_dttm            timestamp  NOT NULL ,
	evnt_typ_cd          varchar(40)  NOT NULL ,
	evnt_payld           JSON  NOT NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	last_updt_dttm       timestamp  NULL ,
	last_updt_by_id      varchar(12)  NULL ,
	evnt_utc_offset      integer  NULL ,
	CONSTRAINT XPKAsset_Timeline PRIMARY KEY (evnt_guid)
);

CREATE INDEX XIF2Asset_Timeln ON assets.Asset_Timeln
(
	party_guid ASC
);

CREATE INDEX XIF3Asset_Timeln ON assets.Asset_Timeln
(
	equip_asset_guid ASC
);

CREATE INDEX XIE1Asset_Timeln ON assets.Asset_Timeln
(
	party_no ASC,
	equip_asset_guid ASC,
	evnt_typ_cd ASC,
	evnt_dttm ASC
);

ALTER TABLE assets.Asset_Timeln RENAME COLUMN last_updt_dttm TO updt_dttm;

ALTER TABLE assets.Asset_Timeln RENAME COLUMN last_updt_by_id TO updt_by_id;

DROP VIEW IF EXISTS assets.asset_latest;

DROP VIEW IF EXISTS assets.telemetry_latest;

DROP VIEW IF EXISTS assets.asset_base;

DROP VIEW IF EXISTS assets.assoc_strct_dlr;

DROP VIEW IF EXISTS assets.assoc_strct_ucid;

DROP MATERIALIZED VIEW IF EXISTS assets.asset_party;

CREATE MATERIALIZED VIEW assets.asset_party_mvw AS
	SELECT DISTINCT a.party_guid, a.equip_asset_guid
	FROM dbo.equip_asset_party_assoc a;

CREATE UNIQUE INDEX uidx_asset_party_mvw

 ON assets.asset_party_mvw (party_guid, equip_asset_guid);

;

CREATE OR REPLACE VIEW assets.Assoc_Strct_Dlr_Vw AS
	SELECT
		ap.equip_asset_guid,
		ap.party_guid,
		dlr.party_no,
		'3' as party_id_typ_cd,
		pa.assoc_strct
	FROM assets.asset_party_mvw ap
	JOIN dbo.dlr dlr on ap.party_guid = dlr.party_guid
	LEFT JOIN LATERAL (
		SELECT json_build_object('associations', json_agg(t2.assoc)) as assoc_strct
		FROM (
			SELECT row_to_json(t) as assoc
			FROM (
				SELECT
					ucid.party_no 	as "ucid",
					ucid.lgl_nm 	as "ucidName",
					dcn.party_no 	as "dcn",
					dcn.lgl_nm 		as "dcnName",
					dlr.party_no 	as "dlr",
					dlr.lgl_nm 		as "dlrName"
				FROM dbo.cust dcn
				JOIN assets.asset_party_mvw a			on a.party_guid = dcn.party_guid and ap.equip_asset_guid = a.equip_asset_guid
				LEFT JOIN dbo.party_xref x 			on x.xref_party_id = dcn.party_guid
				LEFT JOIN dbo.cust ucid 			on x.party_guid = ucid.party_guid
				WHERE dlr.party_no = dcn.src_sub_sys_cd
			) t
		) t2
		LIMIT 1
	) pa ON True;

CREATE OR REPLACE VIEW assets.Assoc_Strct_Ucid_Vw AS
	SELECT
		ap.equip_asset_guid,
		ap.party_guid,
		ucid.party_no,
		'1' as party_id_typ_cd,
		pa.assoc_strct
	FROM assets.asset_party_mvw ap
	JOIN dbo.cust ucid on ap.party_guid = ucid.party_guid
	LEFT JOIN LATERAL (
		SELECT json_build_object('associations', json_agg(t2.assoc)) as assoc_strct
		FROM (
			SELECT row_to_json(t) as assoc
			FROM (
				SELECT
					ucid.party_no 	as "ucid",
					ucid.lgl_nm 	as "ucidName",
					dcn.party_no 	as "dcn",
					dcn.lgl_nm 		as "dcnName",
					dlr.party_no 	as "dlr",
					dlr.lgl_nm 		as "dlrName"
				FROM dbo.party_xref x
				JOIN dbo.cust dcn 					on x.xref_party_id = dcn.party_guid
				JOIN assets.asset_party_mvw a			on a.party_guid = dcn.party_guid and ap.equip_asset_guid = a.equip_asset_guid
				LEFT JOIN dbo.dlr dlr  				on dcn.src_sub_sys_cd = dlr.party_no
				WHERE ucid.party_guid = x.party_guid
			) t
		) t2
		LIMIT 1
	) pa ON True;

CREATE OR REPLACE VIEW assets.asset_base_vw AS
    SELECT
        a.party_guid,
        a.equip_asset_guid,
        o.party_no,
        o.party_id_typ_cd,
        CASE
            WHEN party_id_typ_cd = '1' THEN 'CUST'
            WHEN party_id_typ_cd = '2' THEN 'DCN'
            WHEN party_id_typ_cd = '3' THEN 'DLR'
            ELSE NULL
        END as party_id_typ_nm,
        o.lgl_nm,
        ea.ser_no,
        ea.asset_intrnl_id,
        ea.mfr_cd,
        ea.slsmdl_and_mdfy_no,
        eaan.nm,
        eapa.assoc_nm,
        eapa.assoc_typ_cd,
        pf.prod_fam_cd,
        pf.prod_fam_desc,
        null as dv_typ, --still needed
        null as cnect_ind, --still needed
        COALESCE(dlr_assoc.assoc_strct, ucid_assoc.assoc_strct) as assoc_strct
    FROM assets.asset_party_mvw a
    JOIN dbo.org o							ON a.party_guid = o.party_guid
    JOIN dbo.equip_asset ea				  	ON a.equip_asset_guid = ea.equip_asset_guid
    LEFT JOIN dbo.equip_asset_alt_nm eaan   ON a.equip_asset_guid = eaan.equip_asset_guid AND eaan.nm_typ_cd = '1' AND eaan.src_sub_sys_cd = '-1' AND a.party_guid = eaan.associated_party_id
    LEFT JOIN dbo.prod_fam pf				ON ea.prod_fam_cd = pf.prod_fam_cd AND ea.mfr_cd = pf.mfr_cd
    LEFT JOIN LATERAL
    (
        SELECT eapa.assoc_typ_cd, eapat.assoc_nm
        FROM dbo.equip_asset_party_assoc  eapa
        LEFT JOIN dbo.equip_asset_party_assoc_typ eapat  ON eapa.assoc_typ_cd = eapat.assoc_typ_cd
        WHERE eapa.party_guid = a.party_guid AND eapa.equip_asset_guid = a.equip_asset_guid
        LIMIT 1
    ) eapa on true
    LEFT JOIN LATERAL
    (
        SELECT d.assoc_strct
        FROM assets.assoc_strct_dlr_vw d
        WHERE d.party_guid = a.party_guid and d.equip_asset_guid = a.equip_asset_guid and o.party_id_typ_cd = '3'
        LIMIT 1
    ) dlr_assoc on true
    LEFT JOIN LATERAL
    (
        SELECT u.assoc_strct
        FROM assets.assoc_strct_ucid_vw u
        WHERE u.party_guid = a.party_guid and u.equip_asset_guid = a.equip_asset_guid and o.party_id_typ_cd = '1'
        LIMIT 1
    ) ucid_assoc on true
;

CREATE OR REPLACE VIEW assets.Equip_Asset_Subscrp_Coverage_Start_Vw AS
SELECT o.subscrp_guid
	,o.subscrp_party_guid as party_guid
	,o.subscrp_party_no as party_no
	,o.equip_asset_guid
	,o.subscrp_beg_dttm
FROM (
	SELECT subscrp_party_guid
		,equip_asset_guid
		,subscrp_beg_dttm
		,subscrp_party_no
		,subscrp_guid
		,row_number() OVER (PARTITION BY subscrp_party_guid, equip_asset_guid, subscrp_beg_dttm ORDER BY subscrp_typ_id) AS row_no
	FROM dbo.equip_asset_subscrp
) AS o
	LEFT JOIN dbo.equip_asset_subscrp x
		ON o.subscrp_party_guid = x.subscrp_party_guid
		AND o.equip_asset_guid = x.equip_asset_guid
		AND o.subscrp_beg_dttm > x.subscrp_beg_dttm
		AND o.subscrp_beg_dttm <= x.subscrp_end_dttm
WHERE o.row_no = 1
GROUP BY o.subscrp_guid
	,o.subscrp_party_guid
	,o.subscrp_party_no
	,o.equip_asset_guid
	,o.subscrp_beg_dttm
HAVING count(x.subscrp_guid) = 0
;

CREATE OR REPLACE VIEW assets.Start_Stop_Dtl_Sub_Vw AS
SELECT ssd.message_id
	,sub.subscrp_party_guid
	,sub.subscrp_party_no
	,ssd.equip_asset_guid
	,ssd.start_dttm
	,ssd.stop_dttm
	,ssd.utc_offset
FROM dbo.start_stop_dtl ssd
	INNER JOIN LATERAL (
		SELECT DISTINCT s.subscrp_party_guid
			,s.subscrp_party_no
			,s.equip_asset_guid
		FROM dbo.equip_asset_subscrp s
		WHERE ssd.start_dttm >= s.subscrp_beg_dttm
			AND (ssd.start_dttm <= s.subscrp_end_dttm OR s.subscrp_end_dttm IS NULL)
	) sub
		ON ssd.equip_asset_guid = sub.equip_asset_guid
;

CREATE OR REPLACE VIEW assets.Telemtry_Rptg_Daily_Sub_Vw AS
SELECT trd.message_id
	,sub.subscrp_party_guid
	,sub.subscrp_party_no
	,trd.equip_asset_guid
	,trd.message_dttm
	,trd.utc_offset
FROM dbo.telemtry_rptg_daily AS trd
	INNER JOIN LATERAL (
		SELECT DISTINCT s.subscrp_party_guid
			,s.subscrp_party_no
			,s.equip_asset_guid
		FROM dbo.equip_asset_subscrp s
		WHERE trd.message_dttm >= s.subscrp_beg_dttm
			AND (trd.message_dttm <= s.subscrp_end_dttm OR s.subscrp_end_dttm IS NULL)
	) sub
		ON trd.equip_asset_guid = sub.equip_asset_guid
;

CREATE OR REPLACE VIEW assets.Asset_Timeln_Vw AS
SELECT tl.evnt_guid
	,tl.party_guid
	,tl.party_no
	,tl.equip_asset_guid
	,tl.evnt_typ_cd
	,tl.evnt_dttm
	,tl.evnt_utc_offset
	,tl.evnt_payld
FROM (
	-- deviceStatus: notReporting
	SELECT evnt_guid
		,party_guid
		,party_no
		,equip_asset_guid
		,evnt_typ_cd
		,evnt_dttm
		,evnt_utc_offset
		,evnt_payld
	FROM assets.asset_timeln

	UNION ALL

	-- deviceStatus: awaitingFirstReport
	SELECT MD5(concat('awaitingFirstReport', subscrp_guid))::uuid::character varying AS evnt_guid
		,party_guid
		,party_no
		,equip_asset_guid
		,'deviceStatus' AS evnt_typ_cd
		,subscrp_beg_dttm AS evnt_dttm
		,0 AS evnt_utc_offset
		,json_build_object('status', 'awaitingFirstReport')
	FROM assets.equip_asset_subscrp_coverage_start_vw

	UNION ALL

	-- assetStatus: noStatusReported
	SELECT MD5(concat('noStatusReported', subscrp_guid))::uuid::character varying  AS evnt_guid
		,party_guid
		,party_no
		,equip_asset_guid
		,'assetStatus' AS evnt_typ_cd
		,subscrp_beg_dttm AS evnt_dttm
		,0 AS evnt_utc_offset
		,json_build_object('status', 'noStatusReported')
	FROM assets.equip_asset_subscrp_coverage_start_vw

	UNION ALL

	-- deviceStatus: reporting
	SELECT MD5(concat('reporting', trd.message_id))::uuid::character varying AS evnt_guid
		,trd.subscrp_party_guid AS party_guid
		,trd.subscrp_party_no AS party_no
		,trd.equip_asset_guid
		,'deviceStatus' AS evnt_typ_cd
		,trd.message_dttm AS evnt_dttm
		,trd.utc_offset AS evnt_utc_offset
		,json_build_object('status', 'reporting')
	FROM assets.telemtry_rptg_daily_sub_vw AS trd

	UNION ALL

	-- assetStatus: assetOn
	SELECT MD5(concat('assetOn', ssdtl.message_id))::uuid::character varying AS evnt_guid
		,ssdtl.subscrp_party_guid AS party_guid
		,ssdtl.subscrp_party_no AS party_no
		,ssdtl.equip_asset_guid
		,'assetStatus' AS evnt_typ_cd
		,ssdtl.start_dttm AS evnt_dttm
		,ssdtl.utc_offset AS evnt_utc_offset
		,json_build_object('status', 'assetOn')
	FROM assets.start_stop_dtl_sub_vw AS ssdtl
	WHERE ssdtl.stop_dttm IS NULL

	UNION ALL

	-- assetStatus: assetOff
	SELECT MD5(concat('assetOff', ssdtl.message_id))::uuid::character varying AS evnt_guid
		,ssdtl.subscrp_party_guid AS party_guid
		,ssdtl.subscrp_party_no AS party_no
		,ssdtl.equip_asset_guid
		,'assetStatus' AS evnt_typ_cd
		,ssdtl.stop_dttm AS evnt_dttm
		,ssdtl.utc_offset AS evnt_utc_offset
		,json_build_object('status', 'assetOff')
	FROM assets.start_stop_dtl_sub_vw AS ssdtl
	WHERE ssdtl.stop_dttm IS NOT NULL
) AS tl
;

CREATE OR REPLACE VIEW assets.Asset_Timeln_Latst_Vw AS
SELECT ord.evnt_guid
		,ord.party_guid
		,ord.equip_asset_guid
		,ord.evnt_typ_cd
		,ord.evnt_dttm
		,ord.evnt_utc_offset
		,ord.evnt_payld
FROM (
	SELECT evnt_guid
		,party_guid
		,equip_asset_guid
		,evnt_typ_cd
		,evnt_dttm
		,evnt_utc_offset
		,evnt_payld
		,row_number() OVER(PARTITION BY party_guid, equip_asset_guid, evnt_typ_cd ORDER BY evnt_dttm DESC) AS row_no
	FROM assets.asset_timeln_vw
) ord
WHERE ord.row_no = 1;

CREATE OR REPLACE VIEW assets.telemtry_latst_vw AS
	SELECT
		a.party_guid,
		a.equip_asset_guid,
		l.src						as loc_src,
		l.reverse_geoloc_adr 		as loc_reverse_geoloc_adr,
		l.latitude 					as loc_latitude,
		l.longitude 				as loc_longitude,
		l.message_dttm 				as loc_message_dttm,
		l.utc_offset 				as loc_utc_offset,
		t.src	 					as dist_trav_src,
		t.meas 						as dist_trav_meas,
		t.message_dttm 				as dist_trav_message_dttm,
		t.utc_offset				as dist_trav_utc_offset,
		h.src						as master_smh_src,
		h.meas 						as master_smh_meas,
		h.message_dttm 				as master_smh_message_dttm,
		h.utc_offset				as master_smh_utc_offset,
		d.src						as def_src,
		d.meas 						as def_meas,
		d.message_dttm 				as def_message_dttm,
		d.utc_offset				as def_utc_offset
	FROM assets.asset_party_mvw a
	LEFT JOIN LATERAL
	(
		SELECT 'tsf' as src, reverse_geoloc_adr, latitude, longitude, message_dttm, utc_offset
		FROM dbo.loc_daily d
		WHERE d.equip_asset_guid = a.equip_asset_guid
		ORDER BY d.asset_locl_date desc
		LIMIT 1
	) l on true
	LEFT JOIN LATERAL
	(
		SELECT 'tsf' as src, meas, message_dttm, utc_offset
		FROM dbo.distance_traveled_daily d
		WHERE d.equip_asset_guid = a.equip_asset_guid
		ORDER BY d.asset_locl_date desc
		LIMIT 1
	) t on true
	LEFT JOIN LATERAL
	(
		SELECT 'tsf' as src, meas, message_dttm, utc_offset
		FROM dbo.master_svc_meter_hr_daily d
		WHERE d.equip_asset_guid = a.equip_asset_guid
		ORDER BY d.asset_locl_date desc
		LIMIT 1
	) h on true
	LEFT JOIN LATERAL
	(
		SELECT 'tsf' as src, meas, message_dttm, utc_offset
		FROM dbo.diesel_exhaust_fluid_daily d
		WHERE d.equip_asset_guid = a.equip_asset_guid
		ORDER BY d.asset_locl_date desc
		LIMIT 1
	) d on true;

CREATE OR REPLACE VIEW assets.Asset_Latst_Vw AS
	SELECT
        b.party_guid,
		b.party_no,
		b.party_id_typ_cd,
        b.party_id_typ_nm,
		b.lgl_nm as org_lgl_nm,
        b.equip_asset_guid,
        b.assoc_strct,
		b.ser_no,
		b.asset_intrnl_id,
		b.mfr_cd,
		b.slsmdl_and_mdfy_no,
		b.nm as equip_asset_alt_nm,
		b.assoc_nm as equip_asset_party_typ_assoc_name,
        null as prod_fam_icon_url, --still needed
		b.prod_fam_cd,
		b.prod_fam_desc,
        null as asset_icon_url, --still needed
        null as cnect_ind, --still needed
		tl_asset.asset_stat,
		tl_asset.asset_stat_cd,
		tl_asset.asset_stat_evnt_dttm,
		tl_asset.asset_stat_utc_offset,
        null as telemtry_dv_typ, --still needed
		tl_dv.dv_stat,
		tl_dv.dv_stat_cd,
		tl_dv.dv_stat_evnt_dttm,
		tl_dv.dv_stat_utc_offset,
        t.loc_src,
		t.loc_reverse_geoloc_adr,
		CAST(ST_SetSRID(ST_Point(t.loc_latitude, t.loc_longitude), 4326) AS GEOGRAPHY) as loc_location,
		t.loc_latitude,
		t.loc_longitude,
		t.loc_message_dttm,
		t.loc_utc_offset,
		t.dist_trav_src,
		t.dist_trav_meas,
		t.dist_trav_message_dttm,
		t.dist_trav_utc_offset,
		t.master_smh_src,
		t.master_smh_meas,
		t.master_smh_message_dttm,
		t.master_smh_utc_offset,
		t.def_src,
		t.def_meas,
		t.def_message_dttm,
		t.def_utc_offset
	FROM assets.asset_base_vw b
	LEFT JOIN LATERAL (
		SELECT tl.evnt_dttm AS asset_stat_evnt_dttm
			,tl.evnt_utc_offset AS asset_stat_utc_offset
			,INITCAP(REGEXP_REPLACE(TRIM('"' from (tl.evnt_payld -> 'status')::text), '([a-z])([A-Z])', '\1 \2','g')) AS asset_stat
			,TRIM((tl.evnt_payld -> 'status')::text, '"') AS asset_stat_cd
		FROM assets.asset_timeln_latst_vw tl
 		WHERE b.party_guid = tl.party_guid AND b.equip_asset_guid = tl.equip_asset_guid AND tl.evnt_typ_cd = 'assetStatus'
 		LIMIT 1
	) tl_asset on true
	LEFT JOIN LATERAL (
		SELECT tl.evnt_dttm AS dv_stat_evnt_dttm
			,tl.evnt_utc_offset AS dv_stat_utc_offset
			,INITCAP(REGEXP_REPLACE(TRIM('"' from (tl.evnt_payld -> 'status')::text), '([a-z])([A-Z])', '\1 \2','g')) AS dv_stat
			,TRIM((tl.evnt_payld -> 'status')::text, '"') AS dv_stat_cd
		FROM assets.asset_timeln_latst_vw tl
 		WHERE b.party_guid = tl.party_guid AND b.equip_asset_guid = tl.equip_asset_guid AND tl.evnt_typ_cd = 'deviceStatus'
 		LIMIT 1
	) tl_dv on true
	LEFT JOIN LATERAL (
		SELECT *
		FROM assets.telemtry_latst_vw s
		WHERE b.party_guid = s.party_guid AND b.equip_asset_guid = s.equip_asset_guid
		LIMIT 1
	) t on true
;
