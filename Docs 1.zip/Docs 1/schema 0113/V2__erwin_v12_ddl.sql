CREATE TABLE dbo.Ccy
(
	ccy_cd               char(3)  NOT NULL ,
	ccy_desc             varchar(255)  NULL ,
	ccy_nm               varchar(60)  NOT NULL ,
	ccy_iso_numeric_cd   char(3)  NOT NULL ,
	ccy_beg_dttm         date  NOT NULL ,
	ccy_end_dttm         date  NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(12)  NULL ,
	CONSTRAINT XPKCurrency PRIMARY KEY (ccy_cd)
);

CREATE TABLE dbo.Ccy_Cnvrt
(
	src_ccy_cd           char(3)  NOT NULL ,
	tgt_ccy_cd           char(3)  NOT NULL ,
	ccy_cnvrt_typ_cd     varchar(12)  NOT NULL ,
	ccy_cnvrt_beg_dttm   timestamp  NOT NULL ,
	cnvrt_fctr           float  NOT NULL ,
	end_dttm             timestamp  NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(12)  NULL ,
	CONSTRAINT XPKCurrency_Conversion PRIMARY KEY (src_ccy_cd,tgt_ccy_cd,ccy_cnvrt_typ_cd,ccy_cnvrt_beg_dttm)
);

CREATE INDEX XIF1Currency_Conversion ON dbo.Ccy_Cnvrt
(
	ccy_cnvrt_typ_cd ASC
);

CREATE INDEX XIF2Currency_Conversion ON dbo.Ccy_Cnvrt
(
	tgt_ccy_cd ASC
);

CREATE INDEX XIF3Currency_Conversion ON dbo.Ccy_Cnvrt
(
	src_ccy_cd ASC
);

CREATE TABLE dbo.Ccy_Cnvrt_Typ
(
	ccy_cnvrt_typ_cd     varchar(12)  NOT NULL ,
	ccy_cnvrt_typ_desc   varchar(255)  NULL ,
	ccy_cnvrt_typ_nm     varchar(60)  NOT NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(12)  NULL ,
	CONSTRAINT XPKCurrency_Conversion_Type PRIMARY KEY (ccy_cnvrt_typ_cd)
);

CREATE TABLE dbo.Ccy_Ctry_Xref
(
	ccy_cd               char(3)  NOT NULL ,
	beg_dttm             timestamp  NOT NULL ,
	prim_ccy_ind         boolean  NOT NULL ,
	end_dttm             timestamp  NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(12)  NULL ,
	ctry_cd              char(3)  NOT NULL ,
	CONSTRAINT XPKCurrency_Country_CrossReference PRIMARY KEY (ccy_cd,ctry_cd,beg_dttm)
);

CREATE INDEX XIF1Currency_Country_CrossReference ON dbo.Ccy_Ctry_Xref
(
	ccy_cd   ASC
);

CREATE INDEX XIF2Currency_Country_CrossReference ON dbo.Ccy_Ctry_Xref
(
	ctry_cd  ASC
);

CREATE TABLE dbo.Ccy_Xchg
(
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(12)  NULL ,
	last_updt_dttm       timestamp  NOT NULL ,
	prc_src_nm           varchar(60)  NOT NULL ,
	record_opn_typ       varchar(10)  NULL ,
	err_cd               varchar(12)  NOT NULL ,
	ccy_rate_mltplr      integer  NULL ,
	prc_clse_dttm        timestamp  NULL ,
	ccy_rate_val_cnt     integer  NULL ,
	tgt_ccy_cd           char(3)  NOT NULL ,
	src_ccy_cd           char(3)  NOT NULL ,
	security_data_src_nm varchar(60)  NOT NULL ,
	security_nm          varchar(50)  NOT NULL ,
	CONSTRAINT XPKCurrency_Exchange PRIMARY KEY (last_updt_dttm,tgt_ccy_cd,src_ccy_cd,security_data_src_nm,security_nm)
);

CREATE INDEX XIF3Currency_Exchange ON dbo.Ccy_Xchg
(
	security_data_src_nm ASC,
	security_nm ASC
);

CREATE INDEX XIF4Currency_Exchange ON dbo.Ccy_Xchg
(
	src_ccy_cd ASC
);

CREATE INDEX XIF5Currency_Exchange ON dbo.Ccy_Xchg
(
	tgt_ccy_cd ASC
);

CREATE TABLE dbo.Ccy_Xchg_Rate
(
	ccy_xchg_rate_nm     varchar(50)  NOT NULL ,
	ccy_xchg_rate_val    float  NOT NULL ,
	crte_dttm            timestamp  NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(12)  NOT NULL ,
	src_ccy_cd           char(3)  NOT NULL ,
	tgt_ccy_cd           char(3)  NOT NULL ,
	last_updt_dttm       timestamp  NOT NULL ,
	security_data_src_nm varchar(60)  NOT NULL ,
	security_nm          varchar(50)  NOT NULL ,
	CONSTRAINT XPKCurrency_Exchange_Rate PRIMARY KEY (ccy_xchg_rate_nm,src_ccy_cd,tgt_ccy_cd,last_updt_dttm,security_data_src_nm,security_nm)
);

CREATE INDEX XIF1Currency_Exchange_Rate ON dbo.Ccy_Xchg_Rate
(
	last_updt_dttm ASC,
	security_data_src_nm ASC,
	security_nm ASC,
	src_ccy_cd ASC,
	tgt_ccy_cd ASC
);

CREATE TABLE dbo.Ccy_Xchg_Security
(
	security_nm          varchar(50)  NOT NULL ,
	security_desc        varchar(255)  NOT NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(12)  NULL ,
	security_data_src_nm varchar(60)  NOT NULL ,
	CONSTRAINT XPKCurrency_Exchange_Security PRIMARY KEY (security_nm,security_data_src_nm)
);

CREATE TABLE dbo.Ctry
(
	ctry_cd              char(3)  NOT NULL ,
	ctry_nm              varchar(60)  NOT NULL ,
	ctry_short_nm        varchar(20)  NULL ,
	ctry_iso_2_cd        char(2)  NOT NULL ,
	ctry_dial_cd         varchar(3)  NULL ,
	obs_dttm             timestamp  NULL ,
	ctry_iso_numeric_cd  char(3)  NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(12)  NULL ,
	gvrn_by_ctry_cd      char(3)  NULL ,
	CONSTRAINT XPKCountry PRIMARY KEY (ctry_cd)
);

CREATE INDEX XIF2Country ON dbo.Ctry
(
	gvrn_by_ctry_cd ASC
);

CREATE TABLE dbo.Ctry_Sub_Div_Lvl_2
(
	obs_dttm             timestamp  NULL ,
	ctry_iso_2_cd        varchar(12)  NOT NULL ,
	sub_div_cd           varchar(12)  NOT NULL ,
	sub_div_typ_cd       varchar(12)  NOT NULL ,
	sub_div_digit_2_cd   varchar(12)  NULL ,
	sub_div_nm           varchar(60)  NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(12)  NULL ,
	ctry_cd              char(3)  NOT NULL ,
	CONSTRAINT XPKCountry_Sub_Division_Level_2 PRIMARY KEY (sub_div_cd)
);

CREATE INDEX XIF1Country_Sub_Division_Level_2 ON dbo.Ctry_Sub_Div_Lvl_2
(
	ctry_cd  ASC
);

CREATE TABLE dbo.Party
(
	party_guid           varchar(36)  NOT NULL ,
	party_no             varchar(40)  NOT NULL ,
	party_desc           varchar(255)  NULL ,
	party_typ_cd         varchar(12)  NOT NULL ,
	src_id               varchar(40)  NOT NULL ,
	src_sub_sys_cd       varchar(12)  NULL ,
	party_lang_pref_cd   varchar(12)  NULL ,
	party_prim_role_cd   varchar(12)  NULL ,
	party_id_typ_cd      varchar(12)  NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(12)  NULL ,
	CONSTRAINT XPKParty PRIMARY KEY (party_guid)
);

CREATE UNIQUE INDEX XAK1Party ON dbo.Party
(
	party_no ASC,
	src_sub_sys_cd ASC,
	party_id_typ_cd ASC
);

CREATE INDEX XIF1Party ON dbo.Party
(
	src_id   ASC
);

CREATE INDEX XIF2Party ON dbo.Party
(
	party_lang_pref_cd ASC
);

CREATE INDEX XIF3Party ON dbo.Party
(
	party_prim_role_cd ASC
);

CREATE INDEX XIF4Party ON dbo.Party
(
	party_id_typ_cd ASC
);

CREATE TABLE dbo.Org
(
	inact_dttm           timestamp  NULL ,
	cat_ownshp_ind       boolean  NULL ,
	lgl_nm               varchar(160)  NOT NULL ,
	short_nm             varchar(60)  NULL ,
	dba_nm               varchar(60)  NULL ,
	abr_nm               varchar(60)  NULL ,
	estb_dttm            timestamp  NULL ,
	bus_warn_ind         boolean  NULL ,
	oob_ind              boolean  NULL ,
	pblc_ind             boolean  NULL ,
	bus_beg_yr           char(4)  NULL ,
	-- party_guid           varchar(36)  NOT NULL ,
	CONSTRAINT XPKOrganization PRIMARY KEY (party_guid),
	LIKE dbo.Party
	INCLUDING DEFAULTS
)
INHERITS (dbo.Party);

CREATE UNIQUE INDEX XIF1Organization ON dbo.Org
(
	party_guid ASC
);

CREATE TABLE dbo.Dlr
(
	dlr_typ_cd           VARCHAR(12)  NOT NULL ,
	dlr_sub_typ_cd       VARCHAR(12)  NOT NULL ,
	dlr_str_typ_cd       char(1)  NULL ,
	eops_dlr_str_typ_cd  char(1)  NULL ,
	invstr_reltnshp_cnglm_cd char(1)  NULL ,
	invstr_reltnshp_prim_cd char(1)  NULL ,
	invstr_reltnshp_rent_cd char(1)  NULL ,
	mlbx_char_lmt_cd     varchar(12)  NULL ,
	rspbl_sect_abr       varchar(10)  NULL ,
	mkt_dlr_typ_cd       VARCHAR(12)  NULL ,
	admn_unit_cd         VARCHAR(12)  NULL ,
	aprv_ind             boolean  NULL ,
	-- party_guid           varchar(36)  NOT NULL ,
	CONSTRAINT DLR_PK PRIMARY KEY (party_guid),
	LIKE dbo.Org
	INCLUDING DEFAULTS
)
INHERITS (dbo.Org);

CREATE UNIQUE INDEX XIF1Dealer ON dbo.Dlr
(
	party_guid ASC
);

CREATE TABLE dbo.Cust
(
	indst_cd             varchar(4)  NULL ,
	-- party_guid           varchar(36)  NOT NULL ,
	CONSTRAINT XPKCustomer PRIMARY KEY (party_guid),
	LIKE dbo.Org
	INCLUDING DEFAULTS
)
INHERITS (dbo.Org);

CREATE UNIQUE INDEX XIF1Customer ON dbo.Cust
(
	party_guid ASC
);

CREATE TABLE dbo.Cust_Master
(
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(12)  NULL ,
	party_guid           varchar(36)  NOT NULL ,
	cust_master_guid     varchar(36)  NOT NULL ,
	rev_no               varchar(20)  NOT NULL ,
	CONSTRAINT XPKCustomer_Master PRIMARY KEY (cust_master_guid,rev_no)
);

CREATE UNIQUE INDEX XAK1Customer_Master ON dbo.Cust_Master
(
	party_guid ASC
);

CREATE INDEX XIF2Customer_Master ON dbo.Cust_Master
(
	party_guid ASC
);


CREATE TABLE dbo.Embrgo_Ctry
(
	beg_dttm             timestamp  NOT NULL ,
	end_dttm             timestamp  NULL ,
	regulation_typ_cd    varchar(12)  NOT NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(12)  NULL ,
	imps_ctry_cd         char(3)  NOT NULL ,
	sanctioned_ctry_cd   char(3)  NOT NULL ,
	CONSTRAINT XPKEmbargo_Country PRIMARY KEY (regulation_typ_cd,imps_ctry_cd,beg_dttm,sanctioned_ctry_cd)
);

CREATE INDEX XIF2Embargo_Country ON dbo.Embrgo_Ctry
(
	imps_ctry_cd ASC
);

CREATE INDEX XIF3Embargo_Country ON dbo.Embrgo_Ctry
(
	regulation_typ_cd ASC
);

CREATE INDEX XIF4Embargo_Country ON dbo.Embrgo_Ctry
(
	sanctioned_ctry_cd ASC
);

CREATE TABLE dbo.Embrgo_Regulation_Typ
(
	regulation_typ_cd    varchar(12)  NOT NULL ,
	regulation_nm        varchar(60)  NOT NULL ,
	regulation_desc      varchar(255)  NULL ,
	CONSTRAINT XPKEmbargo_Regulation_Type PRIMARY KEY (regulation_typ_cd)
);

CREATE TABLE dbo.Equip_Asset
(
	equip_asset_guid     varchar(36)  NOT NULL ,
	asset_ctgry_typ_cd   varchar(12)  NOT NULL ,
	asset_intrnl_id      varchar(40)  NOT NULL ,
	slsmdl_and_mdfy_no   varchar(40)  NULL ,
	asset_veh_id_no      varchar(40)  NULL ,
	ser_no               varchar(40)  NOT NULL ,
	prod_fam_cd          varchar(40)  NULL ,
	bld_yr               char(4)  NULL ,
	src_slsmdl_no        VARCHAR(12)  NULL ,
	src_prod_fam_nm      varchar(60)  NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(12)  NULL ,
	ser_no_pfx           char(3)  NULL ,
	ser_no_bdy           varchar(40)  NULL ,
	prin_wrk_cd          char(3)  NULL ,
	mfr_cd               varchar(4)  NOT NULL ,
	equip_asset_typ_cd   varchar(12)  NULL ,
	CONSTRAINT XPKEquipment_Asset PRIMARY KEY (equip_asset_guid)
);

CREATE UNIQUE INDEX XAK1Equipment_Asset ON dbo.Equip_Asset
(
	asset_ctgry_typ_cd ASC,
	asset_intrnl_id ASC,
	mfr_cd   ASC
);

CREATE INDEX XIF2Equipment_Asset ON dbo.Equip_Asset
(
	slsmdl_and_mdfy_no ASC,
	mfr_cd   ASC
);

CREATE INDEX XIF4Equipment_Asset ON dbo.Equip_Asset
(
	mfr_cd   ASC
);

CREATE INDEX XIF5Equipment_Asset ON dbo.Equip_Asset
(
	prod_fam_cd ASC,
	mfr_cd   ASC
);

CREATE INDEX XIF6Equipment_Asset ON dbo.Equip_Asset
(
	asset_ctgry_typ_cd ASC
);

CREATE TABLE dbo.Equip_Asset_Alt_Nm
(
	equip_asset_guid     varchar(36)  NOT NULL ,
	src_id               varchar(40)  NOT NULL ,
	nm_typ_cd            varchar(12)  NOT NULL ,
	associated_party_id  varchar(36)  NULL ,
	nm                   varchar(60)  NOT NULL ,
	nm_beg_dttm          timestamp  NOT NULL ,
	src_sub_sys_cd       varchar(12)  NOT NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(12)  NULL ,
	CONSTRAINT XPKEquipment_Asset_Alternate_Name PRIMARY KEY (equip_asset_guid,src_id,nm_typ_cd,src_sub_sys_cd,nm_beg_dttm)
);

CREATE INDEX XIF1Equipment_Asset_Alternate_Name ON dbo.Equip_Asset_Alt_Nm
(
	equip_asset_guid ASC
);

CREATE INDEX XIF2Equipment_Asset_Alternate_Name ON dbo.Equip_Asset_Alt_Nm
(
	associated_party_id ASC
);

CREATE INDEX XIF3Equipment_Asset_Alternate_Name ON dbo.Equip_Asset_Alt_Nm
(
	src_id   ASC
);

CREATE INDEX XIF4Equipment_Asset_Alternate_Name ON dbo.Equip_Asset_Alt_Nm
(
	nm_typ_cd ASC
);

CREATE TABLE dbo.Equip_Asset_Alt_Nm_Typ
(
	nm_typ_cd            varchar(12)  NOT NULL ,
	alt_typ_nm           varchar(60)  NOT NULL ,
	alt_nm_typ_abr       varchar(10)  NULL ,
	alt_nm_typ_desc      varchar(255)  NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(12)  NULL ,
	CONSTRAINT XPKEquipment_Asset_Alternate_Name_Type PRIMARY KEY (nm_typ_cd)
);

CREATE TABLE dbo.Equip_Asset_Ctgry_Typ
(
	asset_ctgry_typ_cd   varchar(12)  NOT NULL ,
	asset_ctgry_typ_nm   varchar(60)  NOT NULL ,
	asset_ctgry_typ_desc varchar(255)  NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(12)  NULL ,
	CONSTRAINT XPKEquipment_Asset_Category_Type PRIMARY KEY (asset_ctgry_typ_cd)
);

CREATE TABLE dbo.Equip_Asset_Hier
(
	equip_asset_hier_typ_cd varchar(12)  NOT NULL ,
	equip_asset_guid     varchar(36)  NOT NULL ,
	rel_equip_asset_guid varchar(36)  NOT NULL ,
	reltnshp_beg_dttm    timestamp  NOT NULL ,
	reltnshp_end_dttm    timestamp  NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(12)  NULL ,
	CONSTRAINT XPKEquipment_Asset_Hierarchy PRIMARY KEY (equip_asset_hier_typ_cd,equip_asset_guid,rel_equip_asset_guid,reltnshp_beg_dttm)
);

CREATE INDEX XIF1Equipment_Asset_Hierarchy ON dbo.Equip_Asset_Hier
(
	equip_asset_guid ASC
);

CREATE INDEX XIF2Equipment_Asset_Hierarchy ON dbo.Equip_Asset_Hier
(
	rel_equip_asset_guid ASC
);

CREATE INDEX XIF3Equipment_Asset_Hierarchy ON dbo.Equip_Asset_Hier
(
	equip_asset_hier_typ_cd ASC
);

CREATE TABLE dbo.Equip_Asset_Hier_Typ
(
	equip_asset_hier_typ_cd varchar(12)  NOT NULL ,
	equip_asset_hier_nm  char(18)  NULL ,
	equip_asset_hier_desc char(18)  NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(12)  NULL ,
	CONSTRAINT XPKEquipment_Asset_Hierarchy_Type PRIMARY KEY (equip_asset_hier_typ_cd)
);

CREATE TABLE dbo.Equip_Asset_Master
(
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(12)  NULL ,
	rev_no               varchar(20)  NOT NULL ,
	equip_asset_master_guid varchar(36)  NOT NULL ,
	equip_asset_guid     varchar(36)  NOT NULL ,
	CONSTRAINT XPKEquipment_Asset_Master PRIMARY KEY (rev_no,equip_asset_master_guid)
);

CREATE INDEX XIF1Equipment_Asset_Master ON dbo.Equip_Asset_Master
(
	equip_asset_guid ASC
);

CREATE TABLE dbo.Equip_Asset_Party_Assoc
(
	party_guid           varchar(36)  NOT NULL ,
	assoc_typ_cd         VARCHAR(12)  NOT NULL ,
	assoc_beg_dttm       timestamp  NOT NULL ,
	equip_asset_guid     varchar(36)  NOT NULL ,
	assoc_end_dttm       timestamp  NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(12)  NULL ,
	CONSTRAINT XPKEquipment_Asset_Party_Association PRIMARY KEY (party_guid,assoc_typ_cd,equip_asset_guid,assoc_beg_dttm)
);

CREATE INDEX XIF1Equipment_Asset_Party_Association ON dbo.Equip_Asset_Party_Assoc
(
	equip_asset_guid ASC
);

CREATE INDEX XIF2Equipment_Asset_Party_Association ON dbo.Equip_Asset_Party_Assoc
(
	party_guid ASC
);

CREATE INDEX XIF3Equipment_Asset_Party_Association ON dbo.Equip_Asset_Party_Assoc
(
	assoc_typ_cd ASC
);

CREATE TABLE dbo.Equip_Asset_Party_Assoc_Typ
(
	assoc_typ_cd         VARCHAR(12)  NOT NULL ,
	assoc_nm             varchar(60)  NOT NULL ,
	assoc_desc           varchar(255)  NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(12)  NULL ,
	CONSTRAINT XPKEquipment_Asset_Party_Association_Type PRIMARY KEY (assoc_typ_cd)
);

CREATE TABLE dbo.Equip_Asset_Party_Src_Assoc
(
	party_guid           varchar(36)  NOT NULL ,
	equip_asset_guid     varchar(36)  NOT NULL ,
	src_assoc_typ_cd     varchar(12)  NOT NULL ,
	src_id               varchar(40)  NOT NULL ,
	assoc_typ_cd         VARCHAR(12)  NULL ,
	assoc_rpt_dttm       timestamp  NOT NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(12)  NULL ,
	CONSTRAINT XPKEquipment_Asset_Party_Source_Association PRIMARY KEY (src_id,equip_asset_guid,party_guid,src_assoc_typ_cd,assoc_rpt_dttm)
);

CREATE INDEX XIF2Equipment_Asset_Party_Source_Association ON dbo.Equip_Asset_Party_Src_Assoc
(
	equip_asset_guid ASC
);

CREATE INDEX XIF3Equipment_Asset_Party_Source_Association ON dbo.Equip_Asset_Party_Src_Assoc
(
	party_guid ASC
);

CREATE INDEX XIF4Equipment_Asset_Party_Source_Association ON dbo.Equip_Asset_Party_Src_Assoc
(
	src_id   ASC,
	src_assoc_typ_cd ASC
);

CREATE INDEX XIF5Equipment_Asset_Party_Source_Association ON dbo.Equip_Asset_Party_Src_Assoc
(
	assoc_typ_cd ASC
);

CREATE TABLE dbo.Equip_Asset_Party_Src_Assoc_Typ
(
	assoc_typ_cd         VARCHAR(12)  NULL ,
	src_assoc_typ_cd     varchar(12)  NOT NULL ,
	src_id               varchar(40)  NOT NULL ,
	src_assoc_nm         varchar(60)  NOT NULL ,
	src_assoc_desc       varchar(255)  NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(12)  NULL ,
	CONSTRAINT XPKEquipment_Asset_Party_Source_Association_Type PRIMARY KEY (src_assoc_typ_cd,src_id)
);

CREATE INDEX XIF1Equipment_Asset_Party_Source_Association_Type ON dbo.Equip_Asset_Party_Src_Assoc_Typ
(
	assoc_typ_cd ASC
);

CREATE INDEX XIF2Equipment_Asset_Party_Source_Association_Type ON dbo.Equip_Asset_Party_Src_Assoc_Typ
(
	src_id   ASC
);

CREATE TABLE dbo.Equip_Asset_Src_Xref
(
	src_mfr_cd           varchar(12)  NOT NULL ,
	src_asset_id         varchar(40)  NOT NULL ,
	equip_asset_guid     varchar(36)  NULL ,
	src_id               varchar(40)  NOT NULL ,
	cleansed_asset_intrnl_id varchar(40)  NULL ,
	src_slsmdl_no        varchar(40)  NULL ,
	src_prod_fam_nm      varchar(60)  NULL ,
	src_std_mfr_cd       varchar(12)  NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(12)  NULL ,
	prin_wrk_cd          char(3)  NULL ,
	src_sub_sys_cd       varchar(12)  NOT NULL ,
	std_mfr_cd           VARCHAR(4)  NULL ,
	src_ser_no           varchar(40)  NULL ,
	CONSTRAINT XPKEquipment_Asset_Source_CrossReference PRIMARY KEY (src_asset_id,src_id,src_mfr_cd,src_sub_sys_cd)
);

CREATE INDEX XIF1Equipment_Asset_Source_CrossReference ON dbo.Equip_Asset_Src_Xref
(
	equip_asset_guid ASC
);

CREATE INDEX XIF2Equipment_Asset_Source_CrossReference ON dbo.Equip_Asset_Src_Xref
(
	src_id   ASC
);

CREATE INDEX XIF3Equipment_Asset_Source_CrossReference ON dbo.Equip_Asset_Src_Xref
(
	src_sub_sys_cd ASC
);

CREATE TABLE dbo.Equip_Asset_Subscrp
(
	subscrp_beg_dttm     timestamp  NULL ,
	subscrp_end_dttm     timestamp  NULL ,
	subscrp_stat_cd      varchar(12)  NOT NULL ,
	equip_asset_guid     varchar(36)  NOT NULL ,
	subscrp_party_guid   varchar(36)  NULL ,
	subscrp_guid         varchar(36)  NOT NULL ,
	src_id               varchar(40)  NOT NULL ,
	subscrp_associated_party_gloabluniqid varchar(36)  NULL ,
	src_dlr_cust_no      timestamp  NULL ,
	subscrp_nm           varchar(60)  NOT NULL ,
	subscrp_typ_id       varchar(40)  NOT NULL ,
	site_id              varchar(40)  NOT NULL ,
	subscrp_lvl_nm       varchar(60)  NOT NULL ,
	subscrp_cancel_rsn_nm varchar(60)  NOT NULL ,
	catalog_app_nm       varchar(60)  NOT NULL ,
	subscrp_orig_nm      varchar(60)  NOT NULL ,
	CONSTRAINT XPKEquipment_Asset_Subscription PRIMARY KEY (subscrp_guid)
);

CREATE INDEX XIF1Equipment_Asset_Subscription ON dbo.Equip_Asset_Subscrp
(
	equip_asset_guid ASC
);

CREATE INDEX XIF2Equipment_Asset_Subscription ON dbo.Equip_Asset_Subscrp
(
	subscrp_party_guid ASC
);

CREATE INDEX XIF4Equipment_Asset_Subscription ON dbo.Equip_Asset_Subscrp
(
	src_id   ASC
);

CREATE TABLE dbo.Equip_Asset_Typ
(
	equip_asset_typ_cd   varchar(12)  NOT NULL ,
	equip_asset_typ_nm   varchar(60)  NOT NULL ,
	equip_asset_typ_desc varchar(255)  NULL ,
	equip_asset_typ_abr  varchar(10)  NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(12)  NULL ,
	CONSTRAINT XPKEquipment_Asset_Type PRIMARY KEY (equip_asset_typ_cd)
);

CREATE TABLE dbo.Equip_Insp_Ctgry
(
	ctgry_id             varchar(100)  NOT NULL ,
	ctgry_nm             varchar(160)  NULL ,
	CONSTRAINT XPKEquipment_Inspection_Category PRIMARY KEY (ctgry_id)
);

CREATE TABLE dbo.Equip_Insp_Questions
(
	smcs_cmpnt_cd        varchar(4)  NOT NULL ,
	smcs_cmpnt_mdfy_cd   varchar(4)  NOT NULL ,
	smcs_cmpnt_scnd_mdfy_cd varchar(4)  NOT NULL ,
	insp_question_id     integer  NOT NULL ,
	question_prompt_txt  varchar(2000)  NULL ,
	question_no          integer  NULL ,
	response_answer_txt  varchar(2000)  NULL ,
	response_answer_typ_cd varchar(40)  NULL ,
	response_cmnts       text  NULL ,
	response_val_cd      varchar(40)  NULL ,
	par_question_id      varchar(32)  NOT NULL ,
	ctgry_id             varchar(100)  NULL ,
	question_titile_nm   varchar(160)  NULL ,
	prod_cd              varchar(40)  NULL ,
	instruction_picture_ref_id varchar(40)  NOT NULL ,
	instruction_doc_ref_id varchar(40)  NOT NULL ,
	CONSTRAINT XPKEquipment_Inspection_Questions PRIMARY KEY (insp_question_id)
);

CREATE INDEX XIF1Equipment_Inspection_Questions ON dbo.Equip_Insp_Questions
(
	insp_question_id ASC
);

CREATE INDEX XIF2Equipment_Inspection_Questions ON dbo.Equip_Insp_Questions
(
	insp_question_id ASC
);

CREATE INDEX XIF3Equipment_Inspection_Questions ON dbo.Equip_Insp_Questions
(
	ctgry_id ASC
);

CREATE TABLE dbo.Fluid_Smpl
(
	equip_asset_cmprt_typ_cd VARCHAR(12)  NOT NULL ,
	smpl_id              varchar(40)  NOT NULL ,
	smpl_stat_cd         varchar(12)  NOT NULL ,
	smpl_dttm            timestamp  NULL ,
	smpl_rcpt_dttm       timestamp  NULL ,
	sos_cust_no          varchar(40)  NULL ,
	sos_dlr_cd           varchar(12)  NULL ,
	sos_dlr_br_cd        varchar(12)  NULL ,
	srvg_party_id        varchar(36)  NULL ,
	srvg_party_br_id     varchar(36)  NULL ,
	equip_asset_guid     varchar(36)  NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(12)  NULL ,
	sos_cmpnt_ser_no     varchar(40)  NULL ,
	sos_cmpnt_mdl_no     varchar(40)  NULL ,
	sos_cmpnt_mfr_cd     varchar(12)  NULL ,
	svc_meter_read_val   integer  NULL ,
	svc_meter_read_uom_cd varchar(12)  NULL ,
	sos_uom_cd           varchar(12)  NULL ,
	CONSTRAINT XPKFluid_Sample PRIMARY KEY (smpl_id)
);

CREATE INDEX XIF1Fluid_Sample ON dbo.Fluid_Smpl
(
	srvg_party_id ASC
);

CREATE INDEX XIF2Fluid_Sample ON dbo.Fluid_Smpl
(
	srvg_party_br_id ASC
);

CREATE INDEX XIF3Fluid_Sample ON dbo.Fluid_Smpl
(
	equip_asset_guid ASC
);

CREATE INDEX XIF4Fluid_Sample ON dbo.Fluid_Smpl
(
	svc_meter_read_uom_cd ASC
);

CREATE TABLE dbo.Fluid_Smpl_Interpretation
(
	smpl_id              varchar(40)  NOT NULL ,
	interpretation_typ_cd varchar(12)  NULL ,
	interpretation_dttm  timestamp  NULL ,
	interpretation_user_id varchar(40)  NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(12)  NULL ,
	CONSTRAINT XPKFluid_Sample_Interpretation PRIMARY KEY (smpl_id)
);

CREATE INDEX XIF1Fluid_Sample_Interpretation ON dbo.Fluid_Smpl_Interpretation
(
	interpretation_typ_cd ASC
);

CREATE UNIQUE INDEX XIF2Fluid_Sample_Interpretation ON dbo.Fluid_Smpl_Interpretation
(
	smpl_id  ASC
);

CREATE TABLE dbo.Fluid_Smpl_Interpretation_Typ
(
	interpretation_typ_cd varchar(12)  NOT NULL ,
	interpretation_typ_nm varchar(60)  NOT NULL ,
	interpretation_typ_desc varchar(255)  NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(12)  NULL ,
	CONSTRAINT XPKFluid_Sample_Interpretation_Type PRIMARY KEY (interpretation_typ_cd)
);

CREATE TABLE dbo.Insp_Attachment
(
	insp_attachment_id   integer  NOT NULL ,
	attachment_locl_id   varchar(100)  NOT NULL ,
	attachment_src_id    varchar(2000)  NULL ,
	typ_of_media_cd      varchar(40)  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(12)  NULL ,
	crte_dttm            timestamp  NOT NULL ,
	attachment_cmnts     text  NULL ,
	insp_question_id     integer  NULL ,
	CONSTRAINT XPKInspection_Attachment PRIMARY KEY (insp_attachment_id)
);

CREATE INDEX XIF2Inspection_Attachment ON dbo.Insp_Attachment
(
	insp_question_id ASC
);

CREATE TABLE dbo.Insp_Signoffs
(
	signoff_id           integer  NOT NULL ,
	signoff_locl_id      varchar(100)  NOT NULL ,
	signoff_src_id       varchar(2000)  NULL ,
	signoff_typ_of_media_cd varchar(40)  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(12)  NULL ,
	crte_dttm            timestamp  NOT NULL ,
	printed_nm           varchar(160)  NULL ,
	title_nm             varchar(60)  NOT NULL ,
	CONSTRAINT XPKInspection_SignOffs PRIMARY KEY (signoff_id)
);

CREATE TABLE dbo.Lang_Typ
(
	lang_typ_cd          varchar(12)  NOT NULL ,
	lang_nm              varchar(60)  NULL ,
	lang_native_nm       varchar(60)  NOT NULL ,
	iso2_lang_typ_cd     varchar(12)  NOT NULL ,
	iso3_lang_typ_cd     varchar(12)  NOT NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(12)  NULL ,
	CONSTRAINT XPKLanguage_Type PRIMARY KEY (lang_typ_cd)
);

CREATE TABLE dbo.Mfr
(
	mfr_cd               varchar(4)  NOT NULL ,
	mfr_nm               varchar(60)  NOT NULL ,
	mfr_abr              varchar(10)  NULL ,
	mfr_desc             varchar(255)  NULL ,
	rollup_mfr_cd        varchar(12)  NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(12)  NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	CONSTRAINT XPKManufacturer PRIMARY KEY (mfr_cd)
);

CREATE TABLE dbo.Mfr_Xref
(
	src_mfr_cd           varchar(40)  NOT NULL ,
	src_mfr_desc         varchar(255)  NULL ,
	actv_ind             boolean  NULL ,
	xref_beg_dttm        timestamp  NOT NULL ,
	src_id               varchar(40)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	src_sub_sys_cd       varchar(12)  NOT NULL ,
	src_rollup_mfr_cd    varchar(12)  NULL ,
	src_std_mfr_cd       varchar(40)  NULL ,
	updt_by_id           varchar(12)  NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	mfr_cd               varchar(4)  NULL ,
	CONSTRAINT XPKManufacturer_CrossReference PRIMARY KEY (src_id,src_sub_sys_cd,xref_beg_dttm,src_mfr_cd)
);

CREATE INDEX XIF1Manufacturer_CrossReference ON dbo.Mfr_Xref
(
	mfr_cd   ASC
);

CREATE INDEX XIF2Manufacturer_CrossReference ON dbo.Mfr_Xref
(
	src_id   ASC
);



CREATE TABLE dbo.Party_Id_Typ
(
	party_id_typ_cd      varchar(12)  NOT NULL ,
	party_id_typ_nm      varchar(60)  NOT NULL ,
	party_id_typ_desc    varchar(255)  NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(12)  NULL ,
	CONSTRAINT XPKParty_Identification_Type PRIMARY KEY (party_id_typ_cd)
);

CREATE TABLE dbo.Party_Reltnshp
(
	party_guid           varchar(36)  NOT NULL ,
	reltnshp_typ_cd      VARCHAR(12)  NOT NULL ,
	rel_party_guid       varchar(36)  NOT NULL ,
	reltnshp_beg_dttm    timestamp  NOT NULL ,
	reltnshp_end_dttm    timestamp  NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(12)  NULL ,
	CONSTRAINT XPKParty_Relationship PRIMARY KEY (party_guid,reltnshp_typ_cd,rel_party_guid,reltnshp_beg_dttm)
);

CREATE INDEX XIF1Party_Relationship ON dbo.Party_Reltnshp
(
	party_guid ASC
);

CREATE INDEX XIF2Party_Relationship ON dbo.Party_Reltnshp
(
	rel_party_guid ASC
);

CREATE INDEX XIF3Party_Relationship ON dbo.Party_Reltnshp
(
	reltnshp_typ_cd ASC
);

CREATE TABLE dbo.Party_Reltnshp_Typ
(
	reltnshp_typ_cd      VARCHAR(12)  NOT NULL ,
	reltnshp_nm          varchar(60)  NOT NULL ,
	reltnshp_desc        varchar(255)  NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(12)  NULL ,
	CONSTRAINT XPKParty_Relationship_Type PRIMARY KEY (reltnshp_typ_cd)
);

CREATE TABLE dbo.Party_Role
(
	party_roletyp_cd     varchar(12)  NOT NULL ,
	party_role_abr       varchar(10)  NOT NULL ,
	party_role_desc      varchar(255)  NULL ,
	party_role_nm        varchar(60)  NOT NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(12)  NULL ,
	CONSTRAINT XPKParty_Role PRIMARY KEY (party_roletyp_cd)
);

CREATE TABLE dbo.Party_Xref
(
	xref_party_id        varchar(36)  NOT NULL ,
	xref_beg_dttm        timestamp  NOT NULL ,
	xref_end_dttm        timestamp  NULL ,
	party_guid           varchar(36)  NOT NULL ,
	xref_typ_cd          varchar(12)  NOT NULL ,
	actv_ind             boolean  NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(12)  NULL ,
	CONSTRAINT XPKParty_CrossReference PRIMARY KEY (party_guid,xref_party_id,xref_typ_cd,xref_beg_dttm)
);

CREATE INDEX XIF1Party_CrossReference ON dbo.Party_Xref
(
	party_guid ASC
);

CREATE INDEX XIF2Party_CrossReference ON dbo.Party_Xref
(
	xref_party_id ASC
);

CREATE INDEX XIF3Party_CrossReference ON dbo.Party_Xref
(
	xref_typ_cd ASC
);

CREATE TABLE dbo.Party_Xref_Typ
(
	xref_typ_cd          varchar(12)  NOT NULL ,
	xref_nm              varchar(60)  NOT NULL ,
	xref_desc            varchar(255)  NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(12)  NULL ,
	CONSTRAINT XPKParty_CrossReference_Type PRIMARY KEY (xref_typ_cd)
);

CREATE TABLE dbo.Prod_Fam
(
	prod_fam_cd          varchar(40)  NOT NULL ,
	prod_fam_desc        varchar(255)  NOT NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(12)  NULL ,
	mfr_cd               varchar(4)  NOT NULL ,
	CONSTRAINT XPKProduct_Family PRIMARY KEY (prod_fam_cd,mfr_cd)
);

CREATE INDEX XIF1Product_Family ON dbo.Prod_Fam
(
	mfr_cd   ASC
);

CREATE TABLE dbo.Ser_No_Rng_Mdl_Xref
(
	ser_no_bdy_rng_beg_no varchar(40)  NOT NULL ,
	ser_no_pfx           VARCHAR(40)  NOT NULL ,
	ser_no_bdy_rng_end_no varchar(40)  NOT NULL ,
	slsmdl_and_mdfy_no   varchar(40)  NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(12)  NULL ,
	mfr_cd               varchar(4)  NULL ,
	prod_fam_cd          varchar(40)  NULL ,
	sales_mdl_img_ref    varchar(255)  NULL ,
	prod_fam_img_ref     varchar(255)  NULL ,
	engr_mdl_no          varchar(40)  NULL ,
	engeering_mdl_vers_cd varchar(12)  NULL ,
	fac_cd               varchar(12)  NULL ,
	src_id               varchar(40)  NULL ,
	CONSTRAINT I1AKA04011 PRIMARY KEY (ser_no_bdy_rng_beg_no,ser_no_pfx)
);

CREATE INDEX XIF1Serial_Number_Range_Model_CrossReference ON dbo.Ser_No_Rng_Mdl_Xref
(
	slsmdl_and_mdfy_no ASC,
	mfr_cd   ASC
);

CREATE INDEX XIF2Serial_Number_Range_Model_CrossReference ON dbo.Ser_No_Rng_Mdl_Xref
(
	prod_fam_cd ASC,
	mfr_cd   ASC
);

CREATE INDEX XIF3Serial_Number_Range_Model_CrossReference ON dbo.Ser_No_Rng_Mdl_Xref
(
	src_id   ASC
);

CREATE TABLE dbo.Slsmdl
(
	slsmdl_and_mdfy_no   varchar(40)  NOT NULL ,
	prod_fam_cd          varchar(40)  NULL ,
	mkt_slsmdl_no        varchar(40)  NULL ,
	bse_slsmdl_no        varchar(40)  NULL ,
	slsmdl_sfx_cd        varchar(12)  NULL ,
	slsmdl_var_cls_cd    varchar(12)  NULL ,
	slsmdl_srs_cd        varchar(12)  NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(12)  NULL ,
	mfr_cd               varchar(4)  NOT NULL ,
	src_id               varchar(40)  NOT NULL ,
	CONSTRAINT I1AKA040 PRIMARY KEY (slsmdl_and_mdfy_no,mfr_cd)
);

CREATE INDEX XIF3SalesModel ON dbo.Slsmdl
(
	prod_fam_cd ASC,
	mfr_cd   ASC
);

CREATE INDEX XIF4SalesModel ON dbo.Slsmdl
(
	mfr_cd   ASC
);

CREATE INDEX XIF5SalesModel ON dbo.Slsmdl
(
	src_id   ASC
);

CREATE TABLE dbo.Src
(
	src_id               varchar(40)  NOT NULL ,
	src_desc             varchar(255)  NULL ,
	src_nm               varchar(60)  NOT NULL ,
	src_cd               varchar(12)  NOT NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(12)  NULL ,
	actv_ind             boolean  NOT NULL ,
	CONSTRAINT XPKSource PRIMARY KEY (src_id)
);

CREATE TABLE dbo.Subscrp_Cancel_Rsn
(
	subscrp_cancel_rsn_id varchar(40)  NOT NULL ,
	src_id               varchar(40)  NOT NULL ,
	src_cancel_rsn_id    varchar(40)  NOT NULL ,
	subscrp_cancel_rsn_nm varchar(60)  NOT NULL ,
	subscrp_command_nm   varchar(60)  NOT NULL ,
	suspend_subscrp_ind  varchar(12)  NOT NULL ,
	subscrp_cancel_rsn_desc varchar(255)  NULL ,
	CONSTRAINT XPKSubscription_Cancel_Reason PRIMARY KEY (subscrp_cancel_rsn_id)
);

CREATE INDEX XIF1Subscription_Cancel_Reason ON dbo.Subscrp_Cancel_Rsn
(
	src_id   ASC
);

CREATE TABLE dbo.Subscrp_Src_App
(
	subscrp_src_app_id   varchar(40)  NOT NULL ,
	src_id               varchar(40)  NOT NULL ,
	src_app_id           varchar(40)  NOT NULL ,
	src_app_nm           varchar(60)  NOT NULL ,
	user_onboarding_supprt_ind varchar(12)  NOT NULL ,
	subscrp_supprt_ind   varchar(12)  NOT NULL ,
	catalog_app_nm       varchar(60)  NOT NULL ,
	CONSTRAINT XPKSubscription_Source_Application PRIMARY KEY (subscrp_src_app_id)
);

CREATE INDEX XIF1Subscription_Source_Application ON dbo.Subscrp_Src_App
(
	src_id   ASC
);

CREATE TABLE dbo.Subscrp_Typ
(
	subscritption_typ_id varchar(40)  NOT NULL ,
	src_id               varchar(40)  NOT NULL ,
	src_subscrp_typ_id   varchar(40)  NOT NULL ,
	conditional_addons_desc varchar(255)  NULL ,
	subscrp_nm           varchar(60)  NOT NULL ,
	visionlink_desc      varchar(255)  NULL ,
	subscribable_ind     char(18)  NULL ,
	feat_message_supprted_ind char(18)  NULL ,
	software_part_no_txt char(18)  NULL ,
	cnect_asset_candidate_ind char(18)  NULL ,
	cnect_asset_ctgry_cd varchar(12)  NOT NULL ,
	CONSTRAINT XPKSubscription_Type PRIMARY KEY (subscritption_typ_id)
);

CREATE INDEX XIF1Subscription_Type ON dbo.Subscrp_Typ
(
	src_id   ASC
);

CREATE TABLE dbo.Telemtry_Asset
(
	telemtry_asset_guid  varchar(36)  NOT NULL ,
	src_mfr_cd           varchar(12)  NOT NULL ,
	ser_no               varchar(40)  NOT NULL ,
	crte_dttm            timestamp  NULL ,
	crte_by_id           varchar(40)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(40)  NOT NULL ,
	equip_asset_guid     varchar(36)  NOT NULL ,
	CONSTRAINT XPKTelemetry_Asset PRIMARY KEY (telemtry_asset_guid)
);

CREATE UNIQUE INDEX XIF1Telemetry_Asset ON dbo.Telemtry_Asset
(
	equip_asset_guid ASC
);

CREATE TABLE dbo.Telemtry_Dv
(
	telemtry_dv_guid     varchar(36)  NOT NULL ,
	dv_ser_no            integer  NOT NULL ,
	intrnl_dv_id         varchar(40)  NOT NULL ,
	cmml_typ             varchar(40)  NOT NULL ,
	dv_typ               varchar(40)  NOT NULL ,
	dv_stat              varchar(20)  NULL ,
	hardware_part_no     varchar(40)  NULL ,
	crte_dttm            timestamp  NULL ,
	crte_by_id           varchar(40)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(40)  NOT NULL ,
	over_the_air_svc_provisioning_stat varchar(12)  NOT NULL ,
	radio_typ            varchar(40)  NOT NULL ,
	CONSTRAINT XPKTelemetry_Device PRIMARY KEY (telemtry_dv_guid)
);

CREATE UNIQUE INDEX XAK1Telemetry_Device ON dbo.Telemtry_Dv
(
	dv_typ   ASC,
	dv_ser_no ASC
);

CREATE TABLE dbo.Telemtry_Dv_Assoc
(
	telemtry_dv_assoc_guid varchar(36)  NOT NULL ,
	dv_assoc_beg_dttm    timestamp  NOT NULL ,
	dv_assoc_end_dttm    timestamp  NULL ,
	dv_assoc_actv_ind    boolean  NULL ,
	telemtry_dv_guid     varchar(36)  NOT NULL ,
	telemtry_asset_guid  varchar(36)  NOT NULL ,
	crte_dttm            timestamp  NULL ,
	crte_by_id           varchar(40)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(40)  NOT NULL ,
	CONSTRAINT XPKTelemetry_Device_Association PRIMARY KEY (telemtry_dv_assoc_guid)
);

CREATE UNIQUE INDEX XAK1Telemetry_Device_Association ON dbo.Telemtry_Dv_Assoc
(
	telemtry_dv_guid ASC,
	telemtry_asset_guid ASC,
	dv_assoc_beg_dttm ASC
);

CREATE INDEX XIF2Telemetry_Device_Association ON dbo.Telemtry_Dv_Assoc
(
	telemtry_dv_guid ASC
);

CREATE INDEX XIF3Telemetry_Device_Association ON dbo.Telemtry_Dv_Assoc
(
	telemtry_asset_guid ASC
);

CREATE TABLE dbo.Telemtry_Electr_Ctl_Unit
(
	ecu_ser_no           varchar(40)  NOT NULL ,
	hardware_part_no     varchar(40)  NOT NULL ,
	ecu_id               varchar(40)  NOT NULL ,
	datalink_id          varchar(40)  NOT NULL ,
	mod_id               varchar(40)  NOT NULL ,
	eng_ind              boolean  NULL ,
	trnsm_ind            boolean  NULL ,
	cat_data_link_ind    boolean  NULL ,
	j1939_ind            boolean  NULL ,
	sync_clck_enabled_ind boolean  NULL ,
	troubleshooting_cd_protocol integer  NULL ,
	datalink_adr_typ_cd  char(1)  NULL ,
	acting_master_ind    boolean  NULL ,
	j1939_pblc_nm        varchar(60)  NULL ,
	j1939_identy_no      integer  NULL ,
	j1939_mfg_cd         varchar(40)  NULL ,
	j1939_ecu_instance   integer  NULL ,
	j1939_fnct_instance  integer  NULL ,
	j1939_fnct_cd        varchar(12)  NULL ,
	j1939_veh_sys_instance integer  NULL ,
	j1939_veh_sys        integer  NULL ,
	j1939_indst_grp      integer  NULL ,
	j1939_arbitrary_adr_capable integer  NULL ,
	telemtry_ecu_guid    varchar(36)  NOT NULL ,
	crte_dttm            timestamp  NULL ,
	crte_by_id           varchar(40)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(40)  NOT NULL ,
	CONSTRAINT Identifier PRIMARY KEY (telemtry_ecu_guid)
);

CREATE TABLE dbo.Telemtry_Electr_Ctl_Unit_Assoc
(
	telemetery_ecu_assoc_guid varchar(36)  NOT NULL ,
	ecu_assoc_beg_dttm   timestamp  NOT NULL ,
	ecu_assoc_end_dttm   timestamp  NULL ,
	ecu_assoc_actv_ind   boolean  NULL ,
	telemtry_asset_guid  varchar(36)  NOT NULL ,
	telemtry_ecu_guid    varchar(36)  NOT NULL ,
	crte_dttm            timestamp  NULL ,
	crte_by_id           varchar(40)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(40)  NOT NULL ,
	CONSTRAINT XPKTelemetry_Electronic_Control_Unit_Association PRIMARY KEY (telemetery_ecu_assoc_guid)
);

CREATE UNIQUE INDEX XAK1Telemetry_Electronic_Control_Unit_Association ON dbo.Telemtry_Electr_Ctl_Unit_Assoc
(
	telemtry_asset_guid ASC,
	telemtry_ecu_guid ASC,
	ecu_assoc_beg_dttm ASC
);

CREATE INDEX XIF4Telemetry_Electronic_Control_Unit_Association ON dbo.Telemtry_Electr_Ctl_Unit_Assoc
(
	telemtry_asset_guid ASC
);

CREATE INDEX XIF5Telemetry_Electronic_Control_Unit_Association ON dbo.Telemtry_Electr_Ctl_Unit_Assoc
(
	telemtry_ecu_guid ASC
);

CREATE TABLE dbo.Telemtry_Firmware_Assoc
(
	firmware_assoc_guid  varchar(36)  NOT NULL ,
	firmware_vers        varchar(40)  NOT NULL ,
	firmware_beg_dttm    timestamp  NOT NULL ,
	firmware_end_dttm    timestamp  NULL ,
	firmware_actv_ind    boolean  NULL ,
	telemtry_radio_cmpnt_guid varchar(36)  NULL ,
	crte_dttm            timestamp  NULL ,
	crte_by_id           varchar(40)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(40)  NOT NULL ,
	telemtry_dv_guid     varchar(36)  NULL ,
	CONSTRAINT XPKTelemetry_Firmware_Association PRIMARY KEY (firmware_assoc_guid)
);

CREATE UNIQUE INDEX XAK1Telemetry_Firmware_Association ON dbo.Telemtry_Firmware_Assoc
(
	telemtry_radio_cmpnt_guid ASC,
	firmware_vers ASC,
	firmware_beg_dttm ASC
);

CREATE INDEX XIF2Telemetry_Firmware_Association ON dbo.Telemtry_Firmware_Assoc
(
	telemtry_radio_cmpnt_guid ASC
);

CREATE INDEX XIF3Telemetry_Firmware_Association ON dbo.Telemtry_Firmware_Assoc
(
	telemtry_dv_guid ASC
);

CREATE TABLE dbo.Telemtry_Messages
(
	record_typ           varchar(60)  NOT NULL ,
	equip_asset_guid     varchar(36)  NOT NULL ,
	CONSTRAINT XPKTelemetry_Messages PRIMARY KEY (record_typ,equip_asset_guid)
);

CREATE INDEX XIF1Telemetry_Messages ON dbo.Telemtry_Messages
(
	equip_asset_guid ASC
);

CREATE TABLE dbo.Telemtry_Radio_Cmpnt
(
	telemtry_radio_cmpnt_guid varchar(36)  NOT NULL ,
	radio_cmpnt_typ      varchar(40)  NOT NULL ,
	port_no              integer  NULL ,
	mobile_equip_id      varchar(40)  NULL ,
	integrated_circuit_card_id varchar(40)  NULL ,
	international_mobile_station_equip_identy varchar(40)  NULL ,
	international_mobile_subscriber_identy varchar(40)  NULL ,
	international_mobile_equip_identy varchar(40)  NULL ,
	mobile_directory_no  varchar(40)  NULL ,
	mobile_station_intrnl_subscriber_directory_no varchar(40)  NULL ,
	cd_div_multiple_access_pref_ind boolean  NULL ,
	communication_meth   varchar(20)  NULL ,
	crte_dttm            timestamp  NULL ,
	crte_by_id           varchar(40)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(40)  NOT NULL ,
	telemtry_dv_guid     varchar(36)  NULL ,
	CONSTRAINT XPKTelemetry_Radio_Component PRIMARY KEY (telemtry_radio_cmpnt_guid)
);

CREATE INDEX XIF1Telemetry_Radio_Component ON dbo.Telemtry_Radio_Cmpnt
(
	telemtry_dv_guid ASC
);

CREATE TABLE dbo.Telemtry_Software_Assoc
(
	software_assoc_guid  varchar(36)  NOT NULL ,
	software_sys_typ_cd  varchar(12)  NOT NULL ,
	software_part_no     varchar(40)  NOT NULL ,
	sortware_beg_dttm    timestamp  NOT NULL ,
	software_end_dttm    timestamp  NULL ,
	software_actv_ind    boolean  NULL ,
	telemtry_dv_guid     varchar(36)  NULL ,
	telemtry_ecu_guid    varchar(36)  NULL ,
	crte_dttm            timestamp  NULL ,
	crte_by_id           varchar(40)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(40)  NOT NULL ,
	CONSTRAINT XPKTelemetry_Software_Association PRIMARY KEY (software_assoc_guid)
);

CREATE UNIQUE INDEX XAK1Telemetry_Software_Association ON dbo.Telemtry_Software_Assoc
(
	telemtry_dv_guid ASC,
	telemtry_ecu_guid ASC,
	software_sys_typ_cd ASC,
	software_part_no ASC,
	sortware_beg_dttm ASC
);

CREATE INDEX XIF2Telemetry_Software_Association ON dbo.Telemtry_Software_Assoc
(
	telemtry_dv_guid ASC
);

CREATE INDEX XIF5Telemetry_Software_Association ON dbo.Telemtry_Software_Assoc
(
	telemtry_ecu_guid ASC
);

CREATE TABLE dbo.Unvald_Asset
(
	unvald_asset_guid    varchar(36)  NOT NULL ,
	nick_nm              varchar(60)  NULL ,
	mfr_cd               VARCHAR(4)  NULL ,
	ser_no               varchar(40)  NULL ,
	party_guid           varchar(36)  NULL ,
	src_id               varchar(40)  NULL ,
	vald_asset_ind       boolean  NOT NULL ,
	vald_dttm            timestamp  NULL ,
	CONSTRAINT XPKUnvalidated_Asset PRIMARY KEY (unvald_asset_guid)
);

CREATE UNIQUE INDEX XAK1Unvalidated_Asset ON dbo.Unvald_Asset
(
	nick_nm  ASC,
	ser_no   ASC,
	mfr_cd   ASC,
	party_guid ASC
);

CREATE INDEX XIF1Unvalidated_Asset ON dbo.Unvald_Asset
(
	party_guid ASC
);

CREATE INDEX XIF2Unvalidated_Asset ON dbo.Unvald_Asset
(
	src_id   ASC
);

CREATE TABLE dbo.Uom
(
	uom_cd               varchar(12)  NOT NULL ,
	uom_abr              varchar(10)  NOT NULL ,
	uom_desc             varchar(255)  NULL ,
	uom_nm               varchar(60)  NOT NULL ,
	uom_ctgry_cd         varchar(12)  NULL ,
	bse_uom_ind          boolean  NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(12)  NULL ,
	CONSTRAINT XPKUnitOfMeasure PRIMARY KEY (uom_cd)
);

CREATE INDEX XIF1UnitOfMeasure ON dbo.Uom
(
	uom_ctgry_cd ASC
);

CREATE TABLE dbo.Uom_Ctgry_Typ
(
	uom_ctgry_cd         varchar(12)  NOT NULL ,
	uom_catergory_nm     varchar(60)  NOT NULL ,
	uom_ctgry_desc       varchar(255)  NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(12)  NULL ,
	CONSTRAINT XPKUnitOfMeasure_Category_Type PRIMARY KEY (uom_ctgry_cd)
);

CREATE TABLE dbo.Uom_Src_Xref
(
	src_sys_uom_cd       varchar(12)  NOT NULL ,
	uom_cd               varchar(12)  NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NULL ,
	updt_by_id           varchar(12)  NULL ,
	src_id               varchar(40)  NOT NULL ,
	xref_beg_dttm        timestamp  NOT NULL ,
	xref_end_dttm        timestamp  NULL ,
	CONSTRAINT XPKUnitOfMeasure_Source_CrossReference PRIMARY KEY (src_sys_uom_cd,src_id,xref_beg_dttm)
);

CREATE INDEX XIF1UnitOfMeasure_Source_CrossReference ON dbo.Uom_Src_Xref
(
	uom_cd   ASC
);

CREATE INDEX XIF2UnitOfMeasure_Source_CrossReference ON dbo.Uom_Src_Xref
(
	src_id   ASC
);
