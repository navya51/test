CREATE VIEW assets.telemetry_latest AS
	SELECT
		a.party_guid,
		a.equip_asset_guid,
		l.src						as loc_src,
		l.reverse_geoloc_adr 		as loc_reverse_geoloc_adr,
		l.lat 						as loc_lat,
		l.long 						as loc_long,
		l.message_timestmp 			as loc_message_timestmp,
		l.universaltimecordd_offset as loc_universaltimecordd_offset,
		t.src	 					as dist_trav_src,
		t.meas 						as dist_trav_meas,
		t.message_timestmp 			as dist_trav_message_timestmp,
		t.universaltimecordd_offset as dist_trav_universaltimecordd_offset,
		h.src						as master_smh_src,
		h.meas 						as master_smh_meas,
		h.message_timestmp 			as master_smh_message_timestmp,
		h.universaltimecordd_offset as master_smh_universaltimecordd_offset,
		d.src						as def_src,
		d.meas 						as def_meas,
		d.message_timestmp 			as def_message_timestmp,
		d.universaltimecordd_offset as def_universaltimecordd_offset
	FROM assets.asset_party a
	LEFT JOIN LATERAL
	(
		SELECT 'tsf' as src, reverse_geoloc_adr, lat, long, message_timestmp, universaltimecordd_offset
		FROM dbo.loc_daily d
		WHERE d.equip_asset_guid = a.equip_asset_guid
		ORDER BY d.asset_locl_date desc
		LIMIT 1
	) l on true
	LEFT JOIN LATERAL
	(
		SELECT 'tsf' as src, meas, message_timestmp, universaltimecordd_offset
		FROM dbo.distance_traveled_daily d
		WHERE d.equip_asset_guid = a.equip_asset_guid
		ORDER BY d.asset_locl_date desc
		LIMIT 1
	) t on true
	LEFT JOIN LATERAL
	(
		SELECT 'tsf' as src, meas, message_timestmp, universaltimecordd_offset
		FROM dbo.master_svc_meter_hr_daily d
		WHERE d.equip_asset_guid = a.equip_asset_guid
		ORDER BY d.asset_locl_date desc
		LIMIT 1
	) h on true
	LEFT JOIN LATERAL
	(
		SELECT 'tsf' as src, meas, message_timestmp, universaltimecordd_offset
		FROM dbo.diesel_exhaust_fluid_daily d
		WHERE d.equip_asset_guid = a.equip_asset_guid
		ORDER BY d.asset_locl_date desc
		LIMIT 1
	) d on true;