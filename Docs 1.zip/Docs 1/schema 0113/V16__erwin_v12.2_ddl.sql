ALTER TABLE dbo.equip_asset_subscrp
RENAME COLUMN subscrp_associated_party_gloabluniqid TO subscrp_associated_party_guid;

ALTER TABLE dbo.equip_asset_subscrp ALTER COLUMN subscrp_party_guid SET NOT NULL;
ALTER TABLE dbo.equip_asset_subscrp ALTER COLUMN site_id DROP NOT NULL;
ALTER TABLE dbo.equip_asset_subscrp ALTER COLUMN subscrp_cancel_rsn_nm DROP NOT NULL;
ALTER TABLE dbo.equip_asset_subscrp ALTER COLUMN catalog_app_nm DROP NOT NULL;
ALTER TABLE dbo.equip_asset_subscrp ALTER COLUMN subscrp_orig_nm DROP NOT NULL;

ALTER TABLE dbo.equip_asset_subscrp
    DROP COLUMN src_dlr_cust_no
    ,ADD COLUMN src_dlr_cust_no      varchar(40)  NULL
    ,ADD COLUMN subscrp_party_no     varchar(40)  NOT NULL
    ,ADD COLUMN subscrp_associated_party_no varchar(40)  NULL
    ,ADD COLUMN crte_dttm            timestamp  NOT NULL
    ,ADD COLUMN crte_by_id           varchar(12)  NOT NULL
    ,ADD COLUMN updt_dttm            timestamp  NULL
    ,ADD COLUMN updt_by_id           varchar(12)  NULL
;

CREATE INDEX XIF5Equipment_Asset_Subscription ON dbo.Equip_Asset_Subscrp
(
    subscrp_associated_party_guid ASC
);