CREATE TABLE IF NOT EXISTS assets.asset_timeline
(
    party_no             VARCHAR(40) NOT NULL,
    equip_asset_guid     VARCHAR(36) NOT NULL,
    party_guid           VARCHAR(36) NOT NULL,
    evnt_dttm            TIMESTAMP NOT NULL,
    evnt_utc_offset      INTEGER NULL,
    evnt_type            VARCHAR(40) NOT NULL,
    evnt_payload         JSON NULL,
    evnt_guid            VARCHAR(36) NOT NULL,
    cret_dttm            TIMESTAMP NOT NULL DEFAULT (NOW() AT TIME ZONE 'utc'),
    cret_by_id           VARCHAR(12) NOT NULL,
    updt_dttm            TIMESTAMP NOT NULL DEFAULT (NOW() AT TIME ZONE 'utc'),
    updt_by_id           VARCHAR(12) NOT NULL,
    constraint asset_timeline_pkey primary key (evnt_guid)
);

CREATE INDEX XIE1asset_timeline ON assets.asset_timeline
(
    party_no, equip_asset_guid, evnt_type, evnt_dttm
);
