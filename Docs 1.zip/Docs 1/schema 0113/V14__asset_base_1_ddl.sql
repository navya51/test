CREATE VIEW assets.asset_base AS
	SELECT
		a.party_guid,
		a.equip_asset_guid,
		o.party_no,
		o.party_id_typ_cd,
		CASE
			WHEN party_id_typ_cd = '1' THEN 'CUST'
			WHEN party_id_typ_cd = '2' THEN 'DCN'
			WHEN party_id_typ_cd = '3' THEN 'DLR'
			ELSE NULL
		END as party_id_typ_nm,
		o.lgl_nm,
		ea.ser_no,
		ea.asset_intrnl_id,
		ea.mfr_cd,
		ea.slsmdl_and_mdfy_no,
		eaan.nm,
		eapa.assoc_nm,
		eapa.assoc_typ_cd,
		pf.prod_fam_cd,
		pf.prod_fam_desc,
		null as dv_typ, --still needed
		null as is_conn, --still needed
		COALESCE(dlr_assoc.assoc_strct, ucid_assoc.assoc_strct) as assoc_strct
	FROM assets.asset_party a
	JOIN dbo.org o							ON a.party_guid = o.party_guid
	JOIN dbo.equip_asset ea				  	ON a.equip_asset_guid = ea.equip_asset_guid
	LEFT JOIN dbo.equip_asset_alt_nm eaan   ON a.equip_asset_guid = eaan.equip_asset_guid AND eaan.nm_typ_cd = '1' AND eaan.src_sub_sys_cd = '-1' AND a.party_guid = eaan.associated_party_id
	LEFT JOIN dbo.prod_fam pf				ON ea.prod_fam_cd = pf.prod_fam_cd AND ea.mfr_cd = pf.mfr_cd
	LEFT JOIN LATERAL
	(
		SELECT eapa.assoc_typ_cd, eapat.assoc_nm
		FROM dbo.equip_asset_party_assoc  eapa
		LEFT JOIN dbo.equip_asset_party_assoc_typ eapat  ON eapa.assoc_typ_cd = eapat.assoc_typ_cd
		WHERE eapa.party_guid = a.party_guid AND eapa.equip_asset_guid = a.equip_asset_guid
		LIMIT 1
	) eapa on true
	LEFT JOIN LATERAL
	(
		SELECT d.assoc_strct
		FROM assets.assoc_strct_dlr d
		WHERE d.party_guid = a.party_guid and d.equip_asset_guid = a.equip_asset_guid and o.party_id_typ_cd = '3'
		LIMIT 1
	) dlr_assoc on true
	LEFT JOIN LATERAL
	(
		SELECT u.assoc_strct
		FROM assets.assoc_strct_ucid u
		WHERE u.party_guid = a.party_guid and u.equip_asset_guid = a.equip_asset_guid and o.party_id_typ_cd = '1'
		LIMIT 1
	) ucid_assoc on true;