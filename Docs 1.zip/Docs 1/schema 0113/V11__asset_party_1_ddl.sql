
CREATE MATERIALIZED VIEW assets.asset_party AS
	SELECT DISTINCT a.party_guid, a.equip_asset_guid
	FROM dbo.equip_asset_party_assoc a;

CREATE UNIQUE INDEX uidx_asset_party
  ON assets.asset_party (party_guid, equip_asset_guid);

