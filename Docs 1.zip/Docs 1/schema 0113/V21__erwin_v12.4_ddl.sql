--12.4 Update Script

--Drop tables
DROP TABLE IF EXISTS dbo.Equip_Insp_Ctgry;
DROP TABLE IF EXISTS dbo.Equip_Insp_Questions;
DROP TABLE IF EXISTS dbo.Equip_Asset_Ownshp_Master;


--Alter columns from 12.3 to 12.4
ALTER TABLE dbo.Ccy_Xchg DROP COLUMN record_opn_typ;
ALTER TABLE dbo.Ccy_Xchg DROP COLUMN security_data_src_nm;
ALTER TABLE dbo.Ccy_Xchg_Security DROP COLUMN security_data_src_nm;
ALTER TABLE dbo.Ccy_Xchg_Rate DROP COLUMN security_data_src_nm;
ALTER TABLE dbo.Ctry ADD COLUMN contnt_cd CHAR(2);
ALTER TABLE dbo.Equip_Insp ADD COLUMN uom_abr VARCHAR(10);
ALTER TABLE dbo.Fluid_Smpl ADD COLUMN uom_abr VARCHAR(10);
ALTER TABLE dbo.Uom ADD COLUMN src_id VARCHAR(40);
ALTER TABLE dbo.Uom_Src_Xref ADD COLUMN uom_src_desc VARCHAR(100);
ALTER TABLE dbo.Uom_Src_Xref ADD COLUMN uom_abr VARCHAR(10);


--Create Samual Soto's Indexes
ALTER TABLE dbo.party
    DROP CONSTRAINT IF EXISTS XAK2Party;

ALTER TABLE dbo.party
    DROP CONSTRAINT IF EXISTS XAK3Party;

ALTER TABLE dbo.Party
ADD CONSTRAINT XAK2Party UNIQUE (src_sub_sys_cd,party_guid);

ALTER TABLE dbo.Party
ADD CONSTRAINT XAK3Party UNIQUE (party_no,party_guid);


--Create new Customer Work Order table and indexes
CREATE TABLE dbo.Cust_Wrk_Ord
(
	id                   varchar(36)  NOT NULL ,
	sender_id            varchar(20)  NOT NULL ,
	wrk_ord_no           varchar(100)  NOT NULL ,
	wrk_ord_stat         varchar(1)  NOT NULL ,
	wrk_ord_open_date_time date  NOT NULL ,
	wrk_ord_last_updt_date_time date  NOT NULL ,
	wrk_ord_last_clsed_date_time date  NULL ,
	mfr_cd               varchar(4)  NOT NULL ,
	mfr_mdl              varchar(50)  NOT NULL ,
	mfr_ser_no           varchar(20)  NOT NULL ,
	equip_id             varchar(100)  NULL ,
	wrk_ord_sect_no      varchar(20)  NULL ,
	dtl_rpr_lbr_hrs      decimal(7,2)  NULL ,
	svc_meter_val_rpr    decimal(10,2)  NOT NULL ,
	svc_meter_date_time  date  NULL ,
	svc_meter_unit_of_measure varchar(1)  NOT NULL ,
	smcs_cmpnt_cd        varchar(4)  NOT NULL ,
	smcs_job_cd          varchar(20)  NOT NULL ,
	part_cause_flr       varchar(20)  NULL ,
	grp_cause_flr        varchar(20)  NULL ,
	prod_issue_flr_cplnt varchar(4000)  NULL ,
	prod_issue_flr_cor   varchar(4000)  NULL ,
	cmpnt_in_mfr_cd      varchar(4)  NOT NULL ,
	cmpnt_in_ser_no      varchar(25)  NULL ,
	cmpnt_out_mfr_cd     varchar(4)  NOT NULL ,
	cmpnt_out_ser_no     varchar(25)  NULL ,
	part_nm              varchar(1000)  NULL ,
	part_no              varchar(50)  NOT NULL ,
	crte_date_time       timestamp  NOT NULL ,
	updt_date_time       timestamp  NOT NULL ,
	crte_by              varchar(100)  NULL ,
	crte_by_cws          varchar(100)  NULL ,
	updt_by              varchar(100)  NULL ,
	updt_by_cws          varchar(100)  NULL ,
	CONSTRAINT XPKCustomer_Work_Order PRIMARY KEY (sender_id,wrk_ord_no)
);

CREATE UNIQUE INDEX XAK1Customer_Work_Order ON dbo.Cust_Wrk_Ord
(
	id       ASC
);

--Update incorrect field names in Customer Work Order table
ALTER TABLE dbo.Cust_Wrk_Ord RENAME COLUMN crte_date_time TO crte_dttm;
ALTER TABLE dbo.Cust_Wrk_Ord RENAME COLUMN updt_date_time TO updt_dttm;
ALTER TABLE dbo.Cust_Wrk_Ord RENAME COLUMN crte_by_cws TO crte_by_id;
ALTER TABLE dbo.Cust_Wrk_Ord RENAME COLUMN updt_by_cws TO updt_by_id;
ALTER TABLE dbo.Cust_Wrk_Ord RENAME COLUMN svc_meter_date_time TO svc_meter_dttm;
ALTER TABLE dbo.Cust_Wrk_Ord RENAME COLUMN wrk_ord_open_date_time TO wrk_ord_open_dttm;
ALTER TABLE dbo.Cust_Wrk_Ord RENAME COLUMN wrk_ord_last_updt_date_time TO wrk_ord_last_updt_dttm;
ALTER TABLE dbo.Cust_Wrk_Ord RENAME COLUMN wrk_ord_last_clsed_date_time TO wrk_ord_last_clse_dttm;


--Create new Equipment Service Contracts table and indexes
CREATE TABLE dbo.Equip_Svc_Contracts
(
	contract_guid        varchar(36)  NOT NULL ,
	dlr_cd               varchar(4)  NOT NULL ,
	terr_dlr_cd          varchar(4)  NOT NULL ,
	dlr_cust_no          varchar(40)  NOT NULL ,
	equip_mfr_cd         varchar(4)  NOT NULL ,
	equip_mfr_mdl_cd     varchar(40)  NULL ,
	equip_mfr_ser_no     varchar(40)  NOT NULL ,
	contract_no          varchar(40)  NOT NULL ,
	rev_no               integer  NULL ,
	svc_contract_typ     varchar(50)  NULL ,
	contract_start_dttm  timestamp  NULL ,
	contract_end_dttm    timestamp  NULL ,
	contract_start_svc_meter_unit decimal(16,6)  NULL ,
	contract_end_svc_meter_unit decimal(16,6)  NULL ,
	orig_contract_start_dttm timestamp  NULL ,
	orig_contract_end_dttm timestamp  NULL ,
	svc_contract_typ_desc varchar(100)  NULL ,
	std_svc_contract_typ varchar(4)  NOT NULL ,
	equip_generated_id   varchar(100)  NOT NULL ,
	equip_asset_guid     varchar(36)  NOT NULL ,
	identy_primkey       integer  NOT NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NOT NULL ,
	updt_by_id           varchar(12)  NOT NULL ,
	sender_id_typ        varchar(1)  NOT NULL ,
	updt_ind             varchar(1)  NOT NULL ,
	contract_stat        varchar(1)  NULL ,
	contract_smu_dur     decimal(10,2)  NULL ,
	xpir_scenario        varchar(100)  NULL ,
	insp_by              varchar(100)  NULL ,
	insp_typ             varchar(100)  NULL ,
	oil_sampling_by      varchar(100)  NULL ,
	mtce_typ             varchar(50)  NULL ,
	cmpnt_grp            varchar(4)  NOT NULL ,
	crte_by              varchar(50)  NULL ,
	cmpnt_id             varchar(30)  NULL ,
	equip_typ            varchar(40)  NULL ,
	expired_scenario     varchar(20)  NULL ,
	cnectivity_dv        varchar(50)  NOT NULL ,
	dur                  integer  NULL ,
	stat                 varchar(40)  NULL ,
	principle_wrk_cd     varchar(3)  NOT NULL ,
	indst                varchar(50)  NOT NULL ,
	insp                 varchar(50)  NOT NULL ,
	insp_typ_athena      varchar(30)  NULL ,
	oil_sampling         varchar(30)  NULL ,
	mtce_part            boolean  NULL ,
	dlr_lbr              boolean  NULL ,
	rpr                  boolean  NULL ,
	cmpnt_grp_id         varchar(30)  NULL ,
	br                   varchar(200)  NOT NULL ,
	cust_equip_nm        varchar(200)  NOT NULL ,
	cmnt                 varchar(1000)  NULL ,
	cat_oil              boolean  NULL ,
	cma_rcmnd            boolean  NULL ,
	cust_alert_mgmt_and_advise boolean  NULL ,
	glbl_cust            boolean  NULL ,
	electrical_instl_mtce_aes boolean  NULL ,
	cust_equip_no        varchar(40)  NOT NULL ,
	mechanical_instl_mtce boolean  NULL ,
	prod_link_starting_smu_dttm timestamp  NULL ,
	prod_link_starting_smu integer  NULL ,
	prod_link_last_smu_dttm timestamp  NULL ,
	prod_link_last_smu   integer  NULL ,
	prod_link_dv_id      varchar(40)  NULL ,
	prod_link_dv_nm      varchar(40)  NOT NULL ,
	prod_link_ucid       varchar(40)  NULL ,
	prod_link_ucid_nm    varchar(100)  NOT NULL ,
	prod_link_software_vers varchar(40)  NULL ,
	prod_link_last_cntct_datetiime timestamp  NULL ,
	crte_by_athena       varchar(150)  NULL ,
	crte_by_dttm_athena  timestamp  NULL ,
	updt_by_athena       varchar(150)  NOT NULL ,
	updt_by_dttm_athena  timestamp  NOT NULL ,
	src_id               varchar(40)  NOT NULL ,
	chg_ind              varchar(1)  NOT NULL ,
	app                  varchar(20)  NULL ,
	dlr_party_guid       varchar(36)  NOT NULL ,
	cust_party_guid      varchar(36)  NOT NULL ,
	CONSTRAINT XPKEquipment_Service_Contracts PRIMARY KEY (identy_primkey)
);

CREATE INDEX XIF1Equipment_Service_Contracts ON dbo.Equip_Svc_Contracts
(
	dlr_party_guid ASC
);

CREATE INDEX XIF2Equipment_Service_Contracts ON dbo.Equip_Svc_Contracts
(
	cust_party_guid ASC
);

CREATE INDEX XIF3Equipment_Service_Contracts ON dbo.Equip_Svc_Contracts
(
	src_id   ASC
);

CREATE INDEX XIF4Equipment_Service_Contracts ON dbo.Equip_Svc_Contracts
(
	equip_asset_guid ASC
);


--Create updated version of Equipment Inspection Category table and indexes
CREATE TABLE dbo.Equip_Insp_Ctgry
(
	ctgry_id             varchar(100)  NOT NULL ,
	ctgry_nm             varchar(160)  NULL ,
	insp_no              integer  NOT NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NOT NULL ,
	updt_by_id           varchar(12)  NOT NULL
);

CREATE UNIQUE INDEX XPKEquipment_Inspection_Category ON dbo.Equip_Insp_Ctgry
(
	ctgry_id ASC,
	insp_no  ASC
);

CREATE INDEX XIF1Equipment_Inspection_Category ON dbo.Equip_Insp_Ctgry
(
	insp_no  ASC
);


--Create updated version of Equipment Inspection Questions table and indexes
CREATE TABLE dbo.Equip_Insp_Questions
(
	smcs_cmpnt_cd        varchar(4)  NOT NULL ,
	smcs_cmpnt_mdfy_cd   varchar(4)  NOT NULL ,
	smcs_cmpnt_scnd_mdfy_cd varchar(4)  NOT NULL ,
	insp_question_id     integer  NOT NULL ,
	question_prompt_txt  varchar(2000)  NULL ,
	question_no          integer  NULL ,
	response_answer_txt  varchar(2000)  NULL ,
	response_answer_typ_cd varchar(40)  NULL ,
	response_cmnts       text  NULL ,
	response_val_cd      varchar(40)  NULL ,
	par_question_id      varchar(32)  NOT NULL ,
	ctgry_id             varchar(100)  NULL ,
	question_titile_nm   varchar(160)  NULL ,
	insp_no              integer  NULL ,
	prod_cd              varchar(40)  NULL ,
	instruction_picture_ref_id varchar(40)  NOT NULL ,
	instruction_doc_ref_id varchar(40)  NOT NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NOT NULL ,
	updt_by_id           varchar(12)  NOT NULL
);

CREATE UNIQUE INDEX XPKEquipment_Inspection_Questions ON dbo.Equip_Insp_Questions
(
	insp_question_id ASC
);

CREATE INDEX XIF1Equipment_Inspection_Questions ON dbo.Equip_Insp_Questions
(
	insp_question_id ASC
);

CREATE INDEX XIF2Equipment_Inspection_Questions ON dbo.Equip_Insp_Questions
(
	insp_question_id ASC
);

CREATE INDEX XIF3Equipment_Inspection_Questions ON dbo.Equip_Insp_Questions
(
	ctgry_id ASC,
	insp_no  ASC
);


--Create updated version of Equipment Asset Ownership Master table and indexes
CREATE TABLE dbo.Equip_Asset_Ownshp_Master
(
	assoc_end_dttm       timestamp  NULL ,
	crte_dttm            timestamp  NOT NULL ,
	crte_by_id           varchar(12)  NOT NULL ,
	updt_dttm            timestamp  NOT NULL ,
	updt_by_id           varchar(12)  NOT NULL ,
	assoc_beg_dttm       timestamp  NOT NULL ,
	equip_asset_master_guid varchar(36)  NOT NULL ,
	cust_master_guid     varchar(36)  NOT NULL ,
	cust_master_rev_no   varchar(20)  NOT NULL ,
	equip_asset_master_rev_no varchar(20)  NOT NULL ,
	rev_no               varchar(20)  NOT NULL ,
	CONSTRAINT XPKEquipment_Asset_Ownership_Master PRIMARY KEY (equip_asset_master_guid,equip_asset_master_rev_no,cust_master_guid,cust_master_rev_no,assoc_beg_dttm,rev_no)
);

CREATE INDEX XIF1Equipment_Asset_Ownership_Master ON dbo.Equip_Asset_Ownshp_Master
(
	cust_master_guid ASC,
	cust_master_rev_no ASC
);

CREATE INDEX XIF2Equipment_Asset_Ownership_Master ON dbo.Equip_Asset_Ownshp_Master
(
	equip_asset_master_guid ASC,
	equip_asset_master_rev_no ASC
);


--Update "updt_dttm" and "updt_by_id" fields to default values
UPDATE dbo.ccy SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.ccy_cnvrt SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.ccy_cnvrt_typ SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.ccy_ctry_xref SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.ccy_xchg SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.ccy_xchg_rate SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.ccy_xchg_security SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.ctry SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.ctry_sub_div_lvl_2 SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.cust SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.cust_master SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.dlr SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.embrgo_ctry SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.equip_asset SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.equip_asset_alt_nm SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.equip_asset_alt_nm_typ SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.equip_asset_ctgry_typ SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.equip_asset_hier SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.equip_asset_hier_typ SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.equip_asset_master SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.equip_asset_party_assoc SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.equip_asset_party_assoc_typ SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.equip_asset_party_src_assoc SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.equip_asset_party_src_assoc_typ SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.equip_asset_src_xref SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.equip_asset_subscrp SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.equip_asset_typ SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.equip_insp_ctgry SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.equip_insp_questions SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.fluid_smpl SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.fluid_smpl_interpretation SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.fluid_smpl_interpretation_typ SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.insp_attachment SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.insp_signoffs SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.lang_typ SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.mfr SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.mfr_xref SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.org SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.party SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.party_id_typ SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.party_reltnshp SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.party_reltnshp_typ SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.party_role SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.party_xref SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.party_xref_typ SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.prod_fam SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.ser_no_rng_mdl_xref SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.slsmdl SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.src SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.telemtry_asset SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.telemtry_current SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.telemtry_daily SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.telemtry_dtl SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.telemtry_dv SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.telemtry_dv_assoc SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.telemtry_electr_ctl_unit SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.telemtry_electr_ctl_unit_assoc SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.telemtry_firmware_assoc SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.telemtry_radio_cmpnt SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.telemtry_software_assoc SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.uom SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.uom_ctgry_typ SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';
UPDATE dbo.uom_src_xref SET updt_dttm ='2019-11-29 22:00:00+00', updt_by_id = 'HELIOS';



--Update "updt_dttm" and "updt_by_id" fields to NOT NULL
ALTER TABLE dbo.ccy ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.ccy_cnvrt ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.ccy_cnvrt_typ ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.ccy_ctry_xref ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.ccy_xchg ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.ccy_xchg_rate ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.ccy_xchg_security ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.ctry ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.ctry_sub_div_lvl_2 ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.cust ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.cust_master ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.dlr ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.embrgo_ctry ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.equip_asset ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.equip_asset_alt_nm ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.equip_asset_alt_nm_typ ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.equip_asset_ctgry_typ ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.equip_asset_hier ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.equip_asset_hier_typ ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.equip_asset_master ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.equip_asset_party_assoc ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.equip_asset_party_assoc_typ ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.equip_asset_party_src_assoc ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.equip_asset_party_src_assoc_typ ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.equip_asset_src_xref ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.equip_asset_subscrp ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.equip_asset_typ ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.equip_insp_ctgry ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.equip_insp_questions ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.fluid_smpl ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.fluid_smpl_interpretation ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.fluid_smpl_interpretation_typ ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.insp_attachment ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.insp_signoffs ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.lang_typ ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.mfr ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.mfr_xref ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.org ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.party ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.party_id_typ ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.party_reltnshp ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.party_reltnshp_typ ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.party_role ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.party_xref ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.party_xref_typ ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.prod_fam ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.ser_no_rng_mdl_xref ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.slsmdl ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.src ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.telemtry_asset ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.telemtry_current ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.telemtry_daily ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.telemtry_dtl ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.telemtry_dv ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.telemtry_dv_assoc ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.telemtry_electr_ctl_unit ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.telemtry_electr_ctl_unit_assoc ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.telemtry_firmware_assoc ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.telemtry_radio_cmpnt ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.telemtry_software_assoc ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.uom ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.uom_ctgry_typ ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;
ALTER TABLE dbo.uom_src_xref ALTER COLUMN updt_dttm SET NOT NULL, ALTER COLUMN updt_by_id SET NOT NULL;



--Add updated views for Samuel Soto
CREATE OR REPLACE VIEW assets.telemtry_latst_vw
AS
	SELECT
		a.party_guid,
		a.equip_asset_guid,
		l.src AS loc_src,
		l.reverse_geoloc_adr AS loc_reverse_geoloc_adr,
		l.latitude AS loc_latitude,
		l.longitude AS loc_longitude,
		l.message_dttm AS loc_message_dttm,
		l.utc_offset AS loc_utc_offset,
		t.src AS dist_trav_src,
		t.meas AS dist_trav_meas,
		t.message_dttm AS dist_trav_message_dttm,
		t.utc_offset AS dist_trav_utc_offset,
		h.src AS master_smh_src,
		h.meas AS master_smh_meas,
		h.message_dttm AS master_smh_message_dttm,
		h.utc_offset AS master_smh_utc_offset,
		d.src AS def_src,
		d.meas AS def_meas,
		d.message_dttm AS def_message_dttm,
		d.utc_offset AS def_utc_offset,
		e.src AS def_lvl_src,
		e.meas AS def_lvl_meas,
		e.message_dttm AS def_lvl_message_dttm,
		e.utc_offset AS def_lvl_utc_offset,
		f.src AS fuel_lvl_src,
		f.meas AS fuel_lvl_meas,
		f.message_dttm AS fuel_lvl_message_dttm,
		f.utc_offset AS fuel_lvl_utc_offset
	FROM assets.asset_party_mvw a
	LEFT JOIN LATERAL (
		SELECT
			'tsf'::text AS src,
			d_1.reverse_geoloc_adr,
			d_1.latitude,
			d_1.longitude,
			d_1.message_dttm,
			d_1.utc_offset
		FROM dbo.loc_daily d_1
		WHERE d_1.equip_asset_guid::text = a.equip_asset_guid::text
		ORDER BY d_1.asset_locl_date DESC
		LIMIT 1
	) l ON true
	LEFT JOIN LATERAL (
		SELECT
			'tsf'::text AS src,
			d_1.meas,
			d_1.message_dttm,
			d_1.utc_offset
		FROM dbo.distance_traveled_daily d_1
		WHERE d_1.equip_asset_guid::text = a.equip_asset_guid::text
		ORDER BY d_1.asset_locl_date DESC
		LIMIT 1
	) t ON true
	LEFT JOIN LATERAL (
		SELECT
			'tsf'::text AS src,
			d_1.meas,
			d_1.message_dttm,
			d_1.utc_offset
		FROM dbo.master_svc_meter_hr_daily d_1
		WHERE d_1.equip_asset_guid::text = a.equip_asset_guid::text
		ORDER BY d_1.asset_locl_date DESC
		LIMIT 1
	) h ON true
	LEFT JOIN LATERAL (
		SELECT
			'tsf'::text AS src,
			d_1.meas,
			d_1.message_dttm,
			d_1.utc_offset
		FROM dbo.diesel_exhaust_fluid_daily d_1
		WHERE d_1.equip_asset_guid::text = a.equip_asset_guid::text
		ORDER BY d_1.asset_locl_date DESC
		LIMIT 1
	) d ON true
	LEFT JOIN LATERAL (
		SELECT
			'tsf'::text AS src,
			d_1.meas,
			d_1.message_dttm,
			d_1.utc_offset
		FROM dbo.diesel_exhaust_fluid_lvl_daily d_1
		WHERE d_1.equip_asset_guid::text = a.equip_asset_guid::text
		ORDER BY d_1.asset_locl_date DESC
		LIMIT 1
	) e ON true
	LEFT JOIN LATERAL (
		SELECT
			'tsf'::text AS src,
			d_1.meas,
			d_1.message_dttm,
			d_1.utc_offset
		FROM dbo.fuel_lvl_daily d_1
		WHERE d_1.equip_asset_guid::text = a.equip_asset_guid::text
		ORDER BY d_1.asset_locl_date DESC
		LIMIT 1
	) f ON true;

CREATE OR REPLACE VIEW assets.asset_latst_vw
AS
	SELECT
		b.party_guid,
		b.party_no,
		b.party_id_typ_cd,
		b.party_id_typ_nm,
		b.lgl_nm AS org_lgl_nm,
		b.equip_asset_guid,
		b.assoc_strct,
		b.ser_no,
		b.asset_intrnl_id,
		b.mfr_cd,
		b.slsmdl_and_mdfy_no,
		b.nm AS equip_asset_alt_nm,
		b.assoc_nm AS equip_asset_party_typ_assoc_name,
		NULL::text AS prod_fam_icon_url,
		b.prod_fam_cd,
		b.prod_fam_desc,
		NULL::text AS asset_icon_url,
		NULL::text AS cnect_ind,
		tl_asset.asset_stat,
		tl_asset.asset_stat_cd,
		tl_asset.asset_stat_evnt_dttm,
		tl_asset.asset_stat_utc_offset,
		NULL::text AS telemtry_dv_typ,
		tl_dv.dv_stat,
		tl_dv.dv_stat_cd,
		tl_dv.dv_stat_evnt_dttm,
		tl_dv.dv_stat_utc_offset,
		t.loc_src,
		t.loc_reverse_geoloc_adr,
		st_setsrid(st_point(t.loc_latitude, t.loc_longitude), 4326)::geography AS loc_location,
		t.loc_latitude,
		t.loc_longitude,
		t.loc_message_dttm,
		t.loc_utc_offset,
		t.dist_trav_src,
		t.dist_trav_meas,
		t.dist_trav_message_dttm,
		t.dist_trav_utc_offset,
		t.master_smh_src,
		t.master_smh_meas,
		t.master_smh_message_dttm,
		t.master_smh_utc_offset,
		t.def_src,
		t.def_meas,
		t.def_message_dttm,
		t.def_utc_offset,
		t.def_lvl_src,
		t.def_lvl_meas,
		t.def_lvl_message_dttm,
		t.def_lvl_utc_offset,
		t.fuel_lvl_src,
		t.fuel_lvl_meas,
		t.fuel_lvl_message_dttm,
		t.fuel_lvl_utc_offset
	FROM assets.asset_base_vw b
	LEFT JOIN LATERAL (
		SELECT
			tl.evnt_dttm AS asset_stat_evnt_dttm,
			tl.evnt_utc_offset AS asset_stat_utc_offset,
			initcap(regexp_replace(btrim((tl.evnt_payld -> 'status'::text)::text, '"'::text), '([a-z])([A-Z])'::text, '\1 \2'::text, 'g'::text)) AS asset_stat,
			btrim((tl.evnt_payld -> 'status'::text)::text, '"'::text) AS asset_stat_cd
		FROM assets.asset_timeln_latst_vw tl
		WHERE b.party_guid::text = tl.party_guid::text AND b.equip_asset_guid::text = tl.equip_asset_guid::text AND tl.evnt_typ_cd::text = 'assetStatus'::text
		LIMIT 1
	) tl_asset ON true
	LEFT JOIN LATERAL (
		SELECT
			tl.evnt_dttm AS dv_stat_evnt_dttm,
			tl.evnt_utc_offset AS dv_stat_utc_offset,
			initcap(regexp_replace(btrim((tl.evnt_payld -> 'status'::text)::text, '"'::text), '([a-z])([A-Z])'::text, '\1 \2'::text, 'g'::text)) AS dv_stat,
			btrim((tl.evnt_payld -> 'status'::text)::text, '"'::text) AS dv_stat_cd
		FROM assets.asset_timeln_latst_vw tl
		WHERE b.party_guid::text = tl.party_guid::text AND b.equip_asset_guid::text = tl.equip_asset_guid::text AND tl.evnt_typ_cd::text = 'deviceStatus'::text
		LIMIT 1
	) tl_dv ON true
	LEFT JOIN LATERAL (
		SELECT s.party_guid,
			s.equip_asset_guid,
			s.loc_src,
			s.loc_reverse_geoloc_adr,
			s.loc_latitude,
			s.loc_longitude,
			s.loc_message_dttm,
			s.loc_utc_offset,
			s.dist_trav_src,
			s.dist_trav_meas,
			s.dist_trav_message_dttm,
			s.dist_trav_utc_offset,
			s.master_smh_src,
			s.master_smh_meas,
			s.master_smh_message_dttm,
			s.master_smh_utc_offset,
			s.def_src,
			s.def_meas,
			s.def_message_dttm,
			s.def_utc_offset,
			s.def_lvl_src,
			s.def_lvl_meas,
			s.def_lvl_message_dttm,
			s.def_lvl_utc_offset,
			s.fuel_lvl_src,
			s.fuel_lvl_meas,
			s.fuel_lvl_message_dttm,
			s.fuel_lvl_utc_offset
		FROM assets.telemtry_latst_vw s
		WHERE b.party_guid::text = s.party_guid::text AND b.equip_asset_guid::text = s.equip_asset_guid::text
		LIMIT 1
	) t ON true;