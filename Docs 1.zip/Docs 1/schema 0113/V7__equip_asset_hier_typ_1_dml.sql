INSERT INTO dbo.Equip_Asset_Hier_Typ
(equip_asset_hier_typ_cd, equip_asset_hier_nm, equip_asset_hier_desc, crte_dttm, crte_by_id)
VALUES
('1',  'Parent Asset',  'Parent Asset', current_timestamp, 'devadmin')