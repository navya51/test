# Vue JS Santander Private Banking International

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Compiles and minifies for F2 Container production
```
npm run build-f2
```
### Server http F2 Container for development
```
npm run f2
```

### Development json API server for endpoint test
```
npm run json-serve
```
### Build jsdocs for documentation
```
npm run docs
```

### Run pipel line build tool gulp
```
npm run gulp
```


### Lints and fixes files
```
npm run lint
```
## Project Folder Structure
### Assets
Static Images, SVG

### Components
All Generic Componets that will be user across the app.

### I18n Internationalization
All Global i18n tradutions

### Mixins

Share methods, compute properties between components

### ModularExport 
Component Export Configurations for Open F2

### Store
State manager with Vuex (Mutation, Getters, State), and global services

### Views
Combinations of componets that conform an especific view


### Customize configuration

