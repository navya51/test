/* eslint-disable */
F2_jsonpCallback_com_santander_documents_to_sign({
	"apps":[{
		"html": [
		
			'<div id="documentsToSign">',
			'</div>'
		].join("")
	}],
	"inlineScripts":[],
	"scripts":[
		"<%=BASE_URL%>/js/documentsToSign.js ",
		"<%=BASE_URL%>/apps/customer/com_santander_documents_to_sign.js"
	],
	"styles":[
		"<%=BASE_URL%>/css/documentsToSign.css",
	]
})
