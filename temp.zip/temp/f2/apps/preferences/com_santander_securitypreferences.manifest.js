/* eslint-disable */
F2_jsonpCallback_com_santander_securitypreferences({
	"apps":[{
		"html": [
		
			'<div id="santanderSecurityPre">',
			'</div>'
		].join("")
	}],
	"inlineScripts":[],
	"scripts":[
		"<%=BASE_URL%>/js/securityPreferences.js",
		"<%=BASE_URL%>/apps/preferences/com_santander_securitypreferences.js"
	],
	"styles":[
		"<%=BASE_URL%>/css/securityPreferences.css",
	]
})
