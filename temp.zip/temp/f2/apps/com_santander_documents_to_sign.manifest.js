/* eslint-disable */
F2_jsonpCallback_com_santander_documents_to_sign({
	"apps":[{
		"html": [
		
			'<div id="documentsToSign">',
			'</div>'
		].join("")
	}],
	"inlineScripts":[],
	"scripts":[
		"http://127.0.0.1:8067/js/documentsToSign.js ",
		"http://127.0.0.1:8066/apps/com_santander_documents_to_sign.js"
	],
	"styles":[
		"http://127.0.0.1:8067/css/documentsToSign.css",
	]
})
