export const pt = {
    signin: "Acesso eBanking",
    username:"Nome de usu\u00E1rio",
    Password:"Senha",
    ForgotPassword:"Esqueceu sua senha?",
    CreateUser:"Registrar um novo usu\u00E1rio",
    disclaimer:"Este site foi desenvolvido somente para Usu\u00E1rios Autorizados. Qualquer tentativa de impedir o acesso a este site, bem como de atacar ou acessar ilegalmente e/ou altera-lo, resultar\u00E1 em um processo judicial de acordo com as leis municipais, estaduais, federais e internacionais. Caso tenha acessado este site por engano, favor escrever corretamente o nome da URL que deseja visitar. Reservamos o direito de controlar o acesso a este site de acordo com as pol\u00EDticas da empresa.",
    bindThisDevice:"Registrar este computador",
    bindDeviceQuestion:"Registrar o computador?",
    deviceName:"Nome do Computador",
    bindDeviceLink:"Voc\u00EA j\u00E1 cadastrou este dispositivo?",
    Continue:"Continuar",
    deviceBindMessage : "Caso o sistema continue pedindo para cadastrar seu dispositivo que j\u00E1 foi cadastrado, \u00E9 possivel que seu dispositivo n\u00E3o tenha sido cadastrado corretamente. Para corrigir este problema, prossiga com o processo de login. Ao entrar no sistema, selecione Prefer\u00EAncias de Seguran\u00E7a > Computadores registrados. Clique no \u201Cx\u201D ao lado do dispositivo para remover o cadastro. Voc\u00EA poder\u00E1 ent\u00E3o cadastrar este dispositivo na proxima vez que fizer o login.",
    useCurrentUser:"Use o seu usu\u00E1rio atual. Se voc\u00EA n\u00E3o tiver um, ou o tenha esquecido, por favor entre em contato com voc\u00EA gerente",

};
