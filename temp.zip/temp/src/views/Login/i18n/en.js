export const en = {
    signin:"eBanking Access",
    username:"User Name",
    Password:"Password",
    ForgotPassword:"Forgot your password?",
    CreateUser:"Register a New User",
    disclaimer:"This site is intended for use by Authorized Users only. Any attempt to deny access to, hack into and/or deface this site will result in criminal prosecution under local, state, federal and international law. If you have reached this website in error, please remove yourself by typing the correct URL name of the website intended. We reserve the right to monitor access to/from this website in accordance with the company's policies",
    bindThisDevice:"Register This Computer",
    bindDeviceQuestion:"Register this computer?",
    deviceName:"Computer Name",
    bindDeviceLink:"have you already registered this computer?",
    Continue:"Continue",
}
