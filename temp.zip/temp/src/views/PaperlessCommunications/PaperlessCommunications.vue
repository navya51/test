<template>
</template>
<script src="./PaperlessCommunications.js"> </script>
<style src="./PaperlessCommunications.css"></style>