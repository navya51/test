export const es = {
  password: "Contraseña",
  oldPassword: "Contraseña anterior",
  oldPasswordError:"Se requiere contraseña antigua",
  newPassword: "Nueva contraseña",
  newPasswordError: "Se requiere una nueva contraseña",
  repeatNewPassword: "Verificar contraseña",
  repeatNewPasswordError:"Verificacióm de contraseña es requerida",
  save: "Guardar",
  cancel: "Cancelar",
  update: "Actualizar",
  edit: "Editar",
  delete: "Borrar",
  preferred: "Principal",
  docsToSign: "Documentos para firmar",
  selectToSign: "Por favor seleccione un documento para firmar",
  signSelectedDocs: "Firmar documentos seleccionados"
};
