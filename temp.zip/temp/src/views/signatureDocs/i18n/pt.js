export const pt = {
  password: "Senha",
  oldPassword: "Senha Antiga",
  oldPasswordError:"Senha antiga é necessária",
  newPassword: "Nova senha",
  newPasswordError: "Nova senha é necessária",
  repeatNewPassword: "Verifique a senha",
  repeatNewPasswordError:"Verificar senha é necessária",
  save: "Salve",
  cancel: "Cancelar",
  update: "Atualizar",
  edit: "Editar",
  delete: "Excluir",
  preferred: "Principal",
  docsToSign: "Documentos para assinar",
  selectToSign: "Por favor seleccione un documento para firmar",
  signSelectedDocs: "Assinar documentos selecionados",
  downloadSelected: "Download selecionado"
};
