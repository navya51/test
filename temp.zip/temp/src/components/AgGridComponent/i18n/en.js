export const en = {
  Description: "Description",
  Customer: "Customer",
  CustomerName: "Customer Name",
  Reference: "Reference",
  Date: "Date"
};
