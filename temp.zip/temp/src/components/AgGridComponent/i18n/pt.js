export const pt = {
  Description: "Descripción",
  Customer: "Cliente",
  CustomerName: "nome do cliente",
  Reference: "Referência",
  Date: "Encontro"
};
