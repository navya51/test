export const es = {
  Description: "Descripción",
  Customer: "Cliente",
  CustomerName: "Nombre del cliente",
  Reference: "Referencia",
  Date: "Fecha"
};
