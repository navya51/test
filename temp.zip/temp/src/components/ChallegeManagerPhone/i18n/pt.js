export const pt = {
  user_lockout:"Bloqueio do usuário. Entre em contato com seu administrador",
	AdditionalAuthenticationRequired : "Autentica\u00E7\u00E3o adicional necess\u00E1ria",
	PleaseSelectAnAdditionalAuthenticationProcedure: "Selecione um procedimento adicional de autentica\u00E7\u00E3o",
	CHALLENGE_METHOD_OOBPHONE: "OTP Ligação telefônica",
	CHALLENGE_METHOD_QUESTION: "Perguntas de segurança",
  Accept: "Aceitar",
  close: "Fechar",
	error: "An error occurred please try again later",
	YouWillReceiveACallShortly: "You will receive a call shortly to the phone ending with {label}. Please follow these instructions:<ol><li>When requested, please press the pound key (#)</li><li>When requested, please input the following confirmation code : {code}</li></ol>Upon entry of the confirmation code, the additional authentication will be completed.",
	PleaseAnswerAllSecurityQuestions: "Please answer all security questions",
	TheAdditionalAuthenticationFailedPleaseTryAgain: "The additional authentication failed. Please try again"
};
