export const es = {
  user_lockout : "Usuario bloqueado. Favor contactar a su administrador de seguridad.",
		AdditionalAuthenticationRequired :"Se requiere autenticaci\u00F3n adicional",
		PleaseSelectAnAdditionalAuthenticationProcedure: "Por favor seleccione un procedimiento de autenticaci\u00F3n adicional",
		CHALLENGE_METHOD_OOBPHONE: "OTP Llamada telefónica",
		CHALLENGE_METHOD_QUESTION: "Preguntas de seguridad",
    Accept: "Aceptar",
    close: "Cerrar",
		error: "Ocurrio un error. Por favor intentelo de nuevo mas tarde",
		YouWillReceiveACallShortly: "Usted recibir\u00E1 una llamada en breve al n\u00FAmero terminado en {label}.  Por favor siga las siguientes instrucciones:<ol><li>Cuando se le solicite, presione la tecla de signo de n\u00FAmero (#)</li><li>Cuando se le solicite, introduzca el siguiente c\u00F3digo de confirmaci\u00F3n : {code}</li></ol>Una vez realizados estos pasos, la autenticaci\u00F3n adicional estar\u00E1 completada.",
		PleaseAnswerAllSecurityQuestions: "Por favor responda a todas las preguntas de seguridad",
		TheAdditionalAuthenticationFailedPleaseTryAgain: "La autenticaci\u00F3n adicional fallo, por favor intentelo de nuevo"
};
