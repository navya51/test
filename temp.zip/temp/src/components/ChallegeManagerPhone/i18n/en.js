export const en = {
  user_lockout:"User lockout. Please contact your administrator",
	AdditionalAuthenticationRequired : "Additional authentication required",
	PleaseSelectAnAdditionalAuthenticationProcedure: "Please select an additional authentication procedure",
	CHALLENGE_METHOD_OOBPHONE: "OTP Phone call",
	CHALLENGE_METHOD_QUESTION: "Security questions",
  Accept: "Accept",
  close: "Close",
	error: "An error occurred please try again later",
	YouWillReceiveACallShortly: "You will receive a call shortly to the phone ending with {label}. Please follow these instructions:<ol><li>When requested, please press the pound key (#)</li><li>When requested, please input the following confirmation code : {code}</li></ol>Upon entry of the confirmation code, the additional authentication will be completed.",
	PleaseAnswerAllSecurityQuestions: "Please answer all security questions",
	TheAdditionalAuthenticationFailedPleaseTryAgain: "The additional authentication failed. Please try again"
};
