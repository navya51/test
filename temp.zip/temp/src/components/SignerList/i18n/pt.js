export const pt = {
	signerName:"Nome do signatário",
	signDate:"Data de assinatura",
	requiredSign:"Assinaturas Requeridas",
	viewDoc:"Visualizar Documento",
	close:"Close"
};
