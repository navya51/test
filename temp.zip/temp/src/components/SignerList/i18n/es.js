export const es = {
	signerName:"Nombre del firmante",
	signDate:"Fecha de firma",
	requiredSign:"Firmas Requeridas",
	viewDoc:"Ver documento",
	close:"Cerrar"
};
