export const en = {
  signerName:"Signer Name",
  signDate:"Signature Date",
  requiredSign:"Required Signatures",
  viewDoc:"View Document",
  close:"Close"
};
