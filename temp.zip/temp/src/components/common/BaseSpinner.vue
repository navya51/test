<template>
  <div v-if="isVisible" :class="renderClassName">
    <div/>
    <div/>
    <div/>
    <div/>
    <div/>
    <div/>
    <div/>
    <div/>
    <p>demo render{{isVisible}}</p>
  </div>
</template>
<script>
export default {
    props:{
        isVisible: {
            type: Boolean,
            default: true,
        },
        size:{
            type: String,
            default: "medium",
        }
    },
    computed:{
        renderClassName(){
          return `santander-spinner santander-spinner--${this.size}`
        }
    }
}
</script>

<style scope>
.santander-spinner,
.santander-spinner > div {
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  box-sizing: border-box;
  position: absolute;
  top: 50%;
  left: 50%;
  z-index: 2000;
  transform: translate(-50%, -50%) rotate(90deg);
}

.santander-spinner {
  display: block;
  font-size: 0;
  color: #ddd;
}

.santander-spinner > div {
  display: inline-block;
  float: none;
  background-color: currentColor;
  border: 0 solid currentColor;
  position: absolute;
  top: 50%;
  left: 50%;
  margin-top: -4px;
  margin-left: -4px;
  border-radius: 100px;
  animation: ball-spin-clockwise 1s infinite ease-in-out;
}

.santander-spinner--xx-small {
  width: 1rem;
  height: 1rem;
}

.santander-spinner--xx-small > div {
  width: 0.125rem;
  height: 0.125rem;
}

.santander-spinner--x-small {
  width: 1.25rem;
  height: 1.25rem;
}

.santander-spinner--x-small > div {
  width: 0.25rem;
  height: 0.25rem;
}

.santander-spinner--small {
  width: 1.625rem;
  height: 1.625rem;
}

.santander-spinner--small > div {
  width: 0.375rem;
  height: 0.375rem;
}

.santander-spinner--medium {
  width: 2rem;
  height: 2rem;
}

.santander-spinner--medium > div {
  width: 0.4375rem;
  height: 0.4375rem;
}

.santander-spinner--large {
  width: 3rem;
  height: 3rem;
}

.santander-spinner--large > div {
  width: 0.5625rem;
  height: 0.5625rem;
}

.santander-spinner--brand > div {
  color: #01b6f5 !important;
}

.santander-spinner--inverse > div {
  color: #fff !important;
}

.santander-spinner--neutral > div {
  color: #a4a7b5 !important;
}

.santander-spinner > div:nth-child(1) {
  top: 5%;
  left: 50%;
  animation-delay: -0.875s;
  color: #fe4849;
}

.santander-spinner > div:nth-child(2) {
  top: 18.1801948466%;
  left: 81.8198051534%;
  animation-delay: -0.75s;
  color: #ff6837;
}

.santander-spinner > div:nth-child(3) {
  top: 50%;
  left: 95%;
  animation-delay: -0.625s;
  color: #f8d832;
}

.santander-spinner > div:nth-child(4) {
  top: 81.8198051534%;
  left: 81.8198051534%;
  animation-delay: -0.5s;
  color: #c7e46a;
}

.santander-spinner > div:nth-child(5) {
  top: 94.9999999966%;
  left: 50.0000000005%;
  animation-delay: -0.375s;
  color: #1de9b6;
}

.santander-spinner > div:nth-child(6) {
  top: 81.8198046966%;
  left: 18.1801949248%;
  animation-delay: -0.25s;
  color: #1ad1a3;
}

.santander-spinner > div:nth-child(7) {
  top: 49.9999750815%;
  left: 5.0000051215%;
  animation-delay: -0.125s;
  color: #01b6f5;
}

.santander-spinner > div:nth-child(8) {
  top: 18.179464974%;
  left: 18.1803700518%;
  animation-delay: 0s;
  color: #5c56b6;
}

@-webkit-keyframes ball-spin-clockwise {
  0%,
  100% {
    opacity: 1;
    -webkit-transform: scale(1);
    transform: scale(1);
  }
  20% {
    opacity: 1;
  }
  80% {
    opacity: 0;
    -webkit-transform: scale(0);
    transform: scale(0);
  }
}

@-moz-keyframes ball-spin-clockwise {
  0%,
  100% {
    opacity: 1;
    -moz-transform: scale(1);
    transform: scale(1);
  }
  20% {
    opacity: 1;
  }
  80% {
    opacity: 0;
    -moz-transform: scale(0);
    transform: scale(0);
  }
}

@-o-keyframes ball-spin-clockwise {
  0%,
  100% {
    opacity: 1;
    -o-transform: scale(1);
    transform: scale(1);
  }
  20% {
    opacity: 1;
  }
  80% {
    opacity: 0;
    -o-transform: scale(0);
    transform: scale(0);
  }
}

@keyframes ball-spin-clockwise {
  0%,
  100% {
    opacity: 1;
    -webkit-transform: scale(1);
    -moz-transform: scale(1);
    -o-transform: scale(1);
    transform: scale(1);
  }
  20% {
    opacity: 1;
  }
  80% {
    opacity: 0;
    -webkit-transform: scale(0);
    -moz-transform: scale(0);
    -o-transform: scale(0);
    transform: scale(0);
  }
}
</style>
