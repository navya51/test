<template>
  <div class="santander-main_header">
    <img class="santander-main_logo" src="../../assets/logo.png">
  </div>
</template>

<script>
export default {
    name: 'Header'
}
</script>
<style scoped>
.santander-main_logo {
    width: 195px;
}
</style>