export const es = {
  select: "Seleccionar",
  download: "descargar",
  close: "cerrar"
};
