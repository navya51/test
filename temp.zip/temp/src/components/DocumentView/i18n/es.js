export const es = {
  select: "Seleccionar",
  download: "Descargar",
  close: "Cerrar"
};
