export const pt = {
  select: "Selecione",
  download:"Baixar",
  close:"Perto"
};
