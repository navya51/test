export const pt = {
  select: "Selecione",
  download:"baixar",
  close:"perto"
};
