export const en = {
  select: "Select",
  download:"Download",
  close:"Close"
};
