<template>
  <div>
    <embed src="getPdfUrl" type="application/pdf" />
  </div>
</template>

<script src="./DocumentView.js"></script>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped src="./DocumentView.css"></style>