/**
 * @vue-data {boolean} show modal
 */
export default {
    name: "Modal",
    data: function (){
       return {showModal: false}
    }
}