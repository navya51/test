export const isAuthF2 =()=>{
    return sessionStorage.getItem("santander-f2-apps-access-token");
}