import { ChallengeInitiate, ChallengeStart } from "../services";
import {debugExeption} from '../utils';
export const challengeManager = {
  namespaced: true,
  state: {
    methods: []
  },
  mutations: {
    SET_INITIAL_STATE(state) {
      state.methods = [];
    },
    SET_METHODS(
      state,
      {
        data: {
          challengeInfo: { methods }
        }
      }
    ) {
      state.methods = methods;
    }
  },
  actions: {
    async _challengeInit({ commit }, urlBase, content) {
        commit("SET_INITIAL_STATE")
      try {
        let response = await ChallengeInitiate(urlBase, content);
        if (response.data.actionResult === "challenge") {
          commit("SET_METHODS", response.data);
        } else if (response.data.actionResult === "error") {
          //_handleErroneousActionResult
          // eslint-disable-next-line
          console.log("handel error");
        } else {
          commit("SET_METHODS", response.data);
        }
      } catch (err) {
        //debugException2
        // eslint-disable-next-line
        debugExeption(err);
      }
    },
    async _challengeStart({ commit, state }, urlBase, method) {
        commit("SET_INITIAL_STATE")
      try {
        let response = await ChallengeStart(urlBase, state.methods[2]);
        if (response.data.actionResult === "challenge") {
          console.log(response.data);
        } else if (response.data.actionResult === "error") {
          //_handleErroneousActionResult
          // eslint-disable-next-line
          console.log("handel error");
        } else {
          console.log(response.data);
        }
      } catch (err) {
        //debugException2
        // eslint-disable-next-line
        debugExeption(err);
      }
    }
  }
};
