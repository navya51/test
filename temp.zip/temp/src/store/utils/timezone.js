import jstz from 'jstz';
export const timezone =  jstz.determine()
